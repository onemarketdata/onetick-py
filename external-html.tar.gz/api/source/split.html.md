# otp.Source.split

#### Source.split(expr, cases, default=False)

The method splits data using passed expression `expr` for several
outputs by passed `cases`. The method is the alias for the [`Source.switch()`](https://docs.pip.distribution.sol.onetick.com/api/source/switch.html.md#onetick.py.Source.switch)

* **Parameters:**
  * **expr** ([*Operation*](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)) -- column or column based expression
  * **cases** ([*list*](https://docs.python.org/3/library/stdtypes.html#list)) -- list of values or [`onetick.py.range`](https://docs.pip.distribution.sol.onetick.com/api/misc/range.html.md#onetick.py.range) objects to split by
  * **default** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- `True` adds the default output
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))
* **Return type:**
  Outputs according to passed cases, number of outputs is number of cases plus one if `default=True`

### Examples

```pycon
>>> data = otp.Ticks(X=[0.33, -5.1, otp.nan, 9.4])
>>> r1, r2, r3 = data.split(data['X'], [otp.nan, otp.range(0, 100)], default=True)
>>> otp.run(r1)
                     Time   X
0 2003-12-01 00:00:00.002 NaN
>>> otp.run(r2)
                     Time     X
0 2003-12-01 00:00:00.000  0.33
1 2003-12-01 00:00:00.003  9.40
>>> otp.run(r3)
                     Time    X
0 2003-12-01 00:00:00.001 -5.1
```

#### SEE ALSO
[`Source.switch`](https://docs.pip.distribution.sol.onetick.com/api/source/switch.html.md#onetick.py.Source.switch), [`onetick.py.range`](https://docs.pip.distribution.sol.onetick.com/api/misc/range.html.md#onetick.py.range)

#### SEE ALSO
[`Source.switch()`](https://docs.pip.distribution.sol.onetick.com/api/source/switch.html.md#onetick.py.Source.switch)
<br/>
**SWITCH** OneTick event processor
<br/>
