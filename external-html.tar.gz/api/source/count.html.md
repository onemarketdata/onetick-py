# otp.Source.count (jupyter)

#### Source.count(\*\*kwargs)

Returns the number of ticks in the query.

Adds an aggregation that calculate total ticks count, and *executes a query*.
Result is a single value -- number of ticks. Possible application is the Jupyter when
a developer wants to check data presences for example.

* **Parameters:**
  * **kwargs** -- parameters that will be passed to [`otp.run`](../run.md#onetick.py.run)
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [int](https://docs.python.org/3/library/functions.html#int)

### Examples

```pycon
>>> data = otp.Ticks(X=[1, 2, 3])
>>> data.count()
3
```

```pycon
>>> data = otp.Empty()
>>> data.count()
0
```

#### SEE ALSO
[`onetick.py.agg.count()`](../aggregations/count.md#onetick.py.agg.count)
<br/>
[`otp.run`](../run.md#onetick.py.run)
<br/>
[`onetick.py.Source.head()`](head.md#onetick.py.Source.head)
<br/>
[`onetick.py.Source.tail()`](tail.md#onetick.py.Source.tail)
<br/>
