# otp.Source.deepcopy

#### Source.deepcopy()

Copy all graph and change ids for every node.
More details could be found in [`Source.copy()`](https://docs.pip.distribution.sol.onetick.com/api/source/copy.html.md#onetick.py.Source.copy)

#### SEE ALSO
[`Source.copy`](https://docs.pip.distribution.sol.onetick.com/api/source/copy.html.md#onetick.py.Source.copy)

* **Return type:**
  [*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source)
