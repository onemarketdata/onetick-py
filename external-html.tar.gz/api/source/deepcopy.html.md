# otp.Source.deepcopy

#### Source.deepcopy()

Copy all graph and change ids for every node.
More details could be found in [`Source.copy()`](copy.md#onetick.py.Source.copy)

#### SEE ALSO
[`Source.copy`](copy.md#onetick.py.Source.copy)

* **Return type:**
  [*Source*](root.md#onetick.py.Source)
