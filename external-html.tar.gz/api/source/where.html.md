# otp.Source.where

#### Source.where(condition, discard_on_match=False, stop_on_first_mismatch=False)

Filter ticks that meet the `condition`.

Returns new object, original source object is not modified.

* **Parameters:**
  * **condition** ([`Operation`](../operation/root.md#onetick.py.Operation), [`eval()`](../misc/eval.md#onetick.py.eval)) -- Condition expression to filter ticks or object evaluating another query.
    In the latter case another query should have only one tick as a result with only one field.
  * **discard_on_match** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- 

    Inverts the `condition`.

    Ticks that don't meet the condition will be returned.
  * **stop_on_first_mismatch** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If set, no ticks will be propagated starting with the first tick that does not meet the `condition`.
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [Source](root.md#onetick.py.Source)

### Examples

Filtering based on expression:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3, 4])
>>> data = data.where(data['X'] % 2 == 1)
>>> otp.run(data)
                     Time  X
0 2003-12-01 00:00:00.000  1
1 2003-12-01 00:00:00.002  3
```

Filtering based on the result of another query:

```pycon
>>> another_query = otp.Tick(WHERE='mod(X, 2) = 1')
>>> data = otp.Ticks(X=[1, 2, 3, 4])
>>> data = data.where(otp.eval(another_query))
>>> otp.run(data)
                     Time  X
0 2003-12-01 00:00:00.000  1
1 2003-12-01 00:00:00.002  3
```

Using `discard_on_match` parameter to invert the condition:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3, 4])
>>> data = data.where(data['X'] % 2 == 1, discard_on_match=True)
>>> otp.run(data)
                     Time  X
0 2003-12-01 00:00:00.001  2
1 2003-12-01 00:00:00.003  4
```

Using `stop_on_first_mismatch` parameter to not propagate ticks after first mismatch:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3, 4])
>>> data = data.where(data['X'] % 2 == 1, stop_on_first_mismatch=True)
>>> otp.run(data)
        Time  X
0 2003-12-01  1
```

#### SEE ALSO
[`Source.where_clause()`](where_clause.md#onetick.py.Source.where_clause)
<br/>
[`Source.__getitem__()`](__getitem__.md#onetick.py.Source.__getitem__)
<br/>
**WHERE_CLAUSE** OneTick event processor
<br/>
