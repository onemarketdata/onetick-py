# otp.Source.tail (jupyter)

#### Source.tail(n=5, \*\*kwargs)

*Executes the query* and returns last `n` ticks as a pandas dataframe.

It is useful in the Jupyter case when you want to observe last `n` values.

* **Parameters:**
  * **n** ([*int*](https://docs.python.org/3/library/functions.html#int)) -- number of ticks to return
  * **kwargs** -- parameters will be passed to [`otp.run`](../run.md#onetick.py.run)
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html)

### Examples

```pycon
>>> data = otp.Ticks(X=list('abcdefgik'))
>>> data.tail()[['X']]
    X
0 e
1 f
2 g
3 i
4 k
```

#### SEE ALSO
[`onetick.py.agg.last()`](../aggregations/last.md#onetick.py.agg.last)
<br/>
[`otp.run`](../run.md#onetick.py.run)
<br/>
[`onetick.py.Source.head()`](head.md#onetick.py.Source.head)
<br/>
[`onetick.py.Source.count()`](count.md#onetick.py.Source.count)
<br/>
