# otp.Source.head (jupyter)

#### Source.head(n=5, \*\*kwargs)

*Executes the query* and returns first `n` ticks as a pandas dataframe.

It is useful in the Jupyter case when you want to observe first `n` values.

* **Parameters:**
  * **n** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=5*) -- number of ticks to return
  * **kwargs** -- parameters will be passed to [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run)
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))
* **Return type:**
  [DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html)

### Examples

```pycon
>>> data = otp.Ticks(X=list('abcdefgik'))
>>> data.head()[['X']]
    X
0 a
1 b
2 c
3 d
4 e
```

#### SEE ALSO
[`onetick.py.agg.first()`](https://docs.pip.distribution.sol.onetick.com/api/aggregations/first.html.md#onetick.py.agg.first)
<br/>
[`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run)
<br/>
[`onetick.py.Source.tail()`](https://docs.pip.distribution.sol.onetick.com/api/source/tail.html.md#onetick.py.Source.tail)
<br/>
[`onetick.py.Source.count()`](https://docs.pip.distribution.sol.onetick.com/api/source/count.html.md#onetick.py.Source.count)
<br/>
