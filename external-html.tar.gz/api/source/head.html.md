# otp.Source.head (jupyter)

#### Source.head(n=5, \*\*kwargs)

*Executes the query* and returns first `n` ticks as a pandas dataframe.

It is useful in the Jupyter case when you want to observe first `n` values.

* **Parameters:**
  * **n** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=5*) -- number of ticks to return
  * **kwargs** -- parameters will be passed to [`otp.run`](../run.md#onetick.py.run)
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html)

### Examples

```pycon
>>> data = otp.Ticks(X=list('abcdefgik'))
>>> data.head()[['X']]
    X
0 a
1 b
2 c
3 d
4 e
```

#### SEE ALSO
[`onetick.py.agg.first()`](../aggregations/first.md#onetick.py.agg.first)
<br/>
[`otp.run`](../run.md#onetick.py.run)
<br/>
[`onetick.py.Source.tail()`](tail.md#onetick.py.Source.tail)
<br/>
[`onetick.py.Source.count()`](count.md#onetick.py.Source.count)
<br/>
