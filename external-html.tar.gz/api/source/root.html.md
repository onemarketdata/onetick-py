# otp.Source

### *class* Source

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

Base class for representing Onetick execution graph.
All [onetick-py sources](https://docs.pip.distribution.sol.onetick.com/api/sources/root.html.md#sources) are derived from this class
and have access to all its methods.

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> isinstance(data, otp.Source)
True
```

Also this class can be used to initialize raw source
with the help of `onetick.query` classes, but
it should be done with caution as the user is required to set
such properties as symbol name and tick type manually.

```pycon
>>> data = otp.Source(otq.TickGenerator(bucket_interval=0, fields='long A = 123').tick_type('TT'))
>>> otp.run(data, symbols='LOCAL::')
        Time    A
0 2003-12-04  123
```

* **Parameters:**
  **query_parameters** ([*QueryParameters*](https://docs.pip.distribution.sol.onetick.com/api/misc/query_parameters.html.md#onetick.py.QueryParameters))

## Table Of Contents

* [otp.Source.Symbol](https://docs.pip.distribution.sol.onetick.com/api/source/Symbol.html.md)
* [otp.Source._\_call_\_](https://docs.pip.distribution.sol.onetick.com/api/source/__call__.html.md)
* [otp.Source._\_getitem_\_](https://docs.pip.distribution.sol.onetick.com/api/source/__getitem__.html.md)
* [otp.Source._\_setitem_\_](https://docs.pip.distribution.sol.onetick.com/api/source/__setitem__.html.md)
* [otp.Source.add_fields](https://docs.pip.distribution.sol.onetick.com/api/source/add_fields.html.md)
* [otp.Source.add_prefix](https://docs.pip.distribution.sol.onetick.com/api/source/add_prefix.html.md)
* [otp.Source.add_suffix](https://docs.pip.distribution.sol.onetick.com/api/source/add_suffix.html.md)
* [otp.Source.agg](https://docs.pip.distribution.sol.onetick.com/api/source/agg.html.md)
* [otp.Source.apply](https://docs.pip.distribution.sol.onetick.com/api/source/apply.html.md)
* [otp.Source.cache](https://docs.pip.distribution.sol.onetick.com/api/source/cache.html.md)
* [otp.Source.character_present](https://docs.pip.distribution.sol.onetick.com/api/source/character_present.html.md)
* [otp.Source.copy](https://docs.pip.distribution.sol.onetick.com/api/source/copy.html.md)
* [otp.Source.corp_actions](https://docs.pip.distribution.sol.onetick.com/api/source/corp_actions.html.md)
* [otp.Source.correct_tick_filter](https://docs.pip.distribution.sol.onetick.com/api/source/correct_tick_filter.html.md)
* [otp.Source.count (jupyter)](https://docs.pip.distribution.sol.onetick.com/api/source/count.html.md)
* [otp.Source.deepcopy](https://docs.pip.distribution.sol.onetick.com/api/source/deepcopy.html.md)
* [otp.Source.diff](https://docs.pip.distribution.sol.onetick.com/api/source/diff.html.md)
* [otp.Source.distinct](https://docs.pip.distribution.sol.onetick.com/api/source/distinct.html.md)
* [otp.Source.drop](https://docs.pip.distribution.sol.onetick.com/api/source/drop.html.md)
* [otp.Source.dropna](https://docs.pip.distribution.sol.onetick.com/api/source/dropna.html.md)
* [otp.Source.dump](https://docs.pip.distribution.sol.onetick.com/api/source/dump.html.md)
* [otp.Source.estimate_ts_delay](https://docs.pip.distribution.sol.onetick.com/api/source/estimate_ts_delay.html.md)
* [otp.Source.execute](https://docs.pip.distribution.sol.onetick.com/api/source/execute.html.md)
* [otp.Source.exp_tw_average](https://docs.pip.distribution.sol.onetick.com/api/source/exp_tw_average.html.md)
* [otp.Source.exp_w_average](https://docs.pip.distribution.sol.onetick.com/api/source/exp_w_average.html.md)
* [otp.Source.fillna](https://docs.pip.distribution.sol.onetick.com/api/source/fillna.html.md)
* [otp.Source.find_value_for_percentile](https://docs.pip.distribution.sol.onetick.com/api/source/find_value_for_percentile.html.md)
* [otp.Source.first](https://docs.pip.distribution.sol.onetick.com/api/source/first.html.md)
* [otp.Source.get_name](https://docs.pip.distribution.sol.onetick.com/api/source/get_name.html.md)
* [otp.Source.head (jupyter)](https://docs.pip.distribution.sol.onetick.com/api/source/head.html.md)
* [otp.Source.high](https://docs.pip.distribution.sol.onetick.com/api/source/high.html.md)
* [otp.Source.high_time](https://docs.pip.distribution.sol.onetick.com/api/source/high_time.html.md)
* [otp.Source.if_else](https://docs.pip.distribution.sol.onetick.com/api/source/if_else.html.md)
* [otp.Source.implied_vol](https://docs.pip.distribution.sol.onetick.com/api/source/implied_vol.html.md)
* [otp.Source.insert_at_end](https://docs.pip.distribution.sol.onetick.com/api/source/insert_at_end.html.md)
* [otp.Source.insert_data_quality_event](https://docs.pip.distribution.sol.onetick.com/api/source/insert_data_quality_event.html.md)
* [otp.Source.insert_tick](https://docs.pip.distribution.sol.onetick.com/api/source/insert_tick.html.md)
* [otp.Source.intercept_data_quality](https://docs.pip.distribution.sol.onetick.com/api/source/intercept_data_quality.html.md)
* [otp.Source.intercept_symbol_errors](https://docs.pip.distribution.sol.onetick.com/api/source/intercept_symbol_errors.html.md)
* [otp.Source.join_with_collection](https://docs.pip.distribution.sol.onetick.com/api/source/join_with_collection.html.md)
* [otp.Source.join_with_query](https://docs.pip.distribution.sol.onetick.com/api/source/join_with_query.html.md)
* [otp.Source.join_with_snapshot](https://docs.pip.distribution.sol.onetick.com/api/source/join_with_snapshot.html.md)
* [otp.Source.last](https://docs.pip.distribution.sol.onetick.com/api/source/last.html.md)
* [otp.Source.lee_and_ready](https://docs.pip.distribution.sol.onetick.com/api/source/lee_and_ready.html.md)
* [otp.Source.limit](https://docs.pip.distribution.sol.onetick.com/api/source/limit.html.md)
* [otp.Source.linear_regression](https://docs.pip.distribution.sol.onetick.com/api/source/linear_regression.html.md)
* [otp.Source.logf](https://docs.pip.distribution.sol.onetick.com/api/source/logf.html.md)
* [otp.Source.low](https://docs.pip.distribution.sol.onetick.com/api/source/low.html.md)
* [otp.Source.low_time](https://docs.pip.distribution.sol.onetick.com/api/source/low_time.html.md)
* [otp.Source.meta_fields](https://docs.pip.distribution.sol.onetick.com/api/source/meta_fields.html.md)
* [otp.Source.mkt_activity](https://docs.pip.distribution.sol.onetick.com/api/source/mkt_activity.html.md)
* [otp.Source.modify_query_times](https://docs.pip.distribution.sol.onetick.com/api/source/modify_query_times.html.md)
* [otp.Source.modify_symbol_name](https://docs.pip.distribution.sol.onetick.com/api/source/modify_symbol_name.html.md)
* [otp.Source.multi_portfolio_price](https://docs.pip.distribution.sol.onetick.com/api/source/multi_portfolio_price.html.md)
* [otp.Source.ob_num_levels](https://docs.pip.distribution.sol.onetick.com/api/source/ob_num_levels.html.md)
* [otp.Source.ob_size](https://docs.pip.distribution.sol.onetick.com/api/source/ob_size.html.md)
* [otp.Source.ob_snapshot](https://docs.pip.distribution.sol.onetick.com/api/source/ob_snapshot.html.md)
* [otp.Source.ob_snapshot_flat](https://docs.pip.distribution.sol.onetick.com/api/source/ob_snapshot_flat.html.md)
* [otp.Source.ob_snapshot_wide](https://docs.pip.distribution.sol.onetick.com/api/source/ob_snapshot_wide.html.md)
* [otp.Source.ob_summary](https://docs.pip.distribution.sol.onetick.com/api/source/ob_summary.html.md)
* [otp.Source.ob_vwap](https://docs.pip.distribution.sol.onetick.com/api/source/ob_vwap.html.md)
* [otp.Source.option_price](https://docs.pip.distribution.sol.onetick.com/api/source/option_price.html.md)
* [otp.Source.partition_evenly_into_groups](https://docs.pip.distribution.sol.onetick.com/api/source/partition_evenly_into_groups.html.md)
* [otp.Source.percentile](https://docs.pip.distribution.sol.onetick.com/api/source/percentile.html.md)
* [otp.Source.plot (jupyter)](https://docs.pip.distribution.sol.onetick.com/api/source/plot.html.md)
* [otp.Source.pnl_realized](https://docs.pip.distribution.sol.onetick.com/api/source/pnl_realized.html.md)
* [otp.Source.point_in_time](https://docs.pip.distribution.sol.onetick.com/api/source/point_in_time.html.md)
* [otp.Source.portfolio_price](https://docs.pip.distribution.sol.onetick.com/api/source/portfolio_price.html.md)
* [otp.Source.primary_exch](https://docs.pip.distribution.sol.onetick.com/api/source/primary_exch.html.md)
* [otp.Source.print_otq](https://docs.pip.distribution.sol.onetick.com/api/source/print_otq.html.md)
* [otp.Source.process_by_group](https://docs.pip.distribution.sol.onetick.com/api/source/process_by_group.html.md)
* [otp.Source.ranking](https://docs.pip.distribution.sol.onetick.com/api/source/ranking.html.md)
* [otp.Source.rename](https://docs.pip.distribution.sol.onetick.com/api/source/rename.html.md)
* [otp.Source.render](https://docs.pip.distribution.sol.onetick.com/api/source/render.html.md)
* [otp.Source.render_otq](https://docs.pip.distribution.sol.onetick.com/api/source/render_otq.html.md)
* [otp.Source.return_ep](https://docs.pip.distribution.sol.onetick.com/api/source/return_ep.html.md)
* [otp.Source.save_snapshot](https://docs.pip.distribution.sol.onetick.com/api/source/save_snapshot.html.md)
* [otp.Source.schema](https://docs.pip.distribution.sol.onetick.com/api/source/schema.html.md)
* [otp.Source.script](https://docs.pip.distribution.sol.onetick.com/api/source/script.html.md)
* [otp.Source.set_name](https://docs.pip.distribution.sol.onetick.com/api/source/set_name.html.md)
* [otp.Source.show_corrected_ticks](https://docs.pip.distribution.sol.onetick.com/api/source/show_corrected_ticks.html.md)
* [otp.Source.show_data_quality](https://docs.pip.distribution.sol.onetick.com/api/source/show_data_quality.html.md)
* [otp.Source.show_hidden_ticks](https://docs.pip.distribution.sol.onetick.com/api/source/show_hidden_ticks.html.md)
* [otp.Source.show_symbol_errors](https://docs.pip.distribution.sol.onetick.com/api/source/show_symbol_errors.html.md)
* [otp.Source.show_symbol_name_in_db](https://docs.pip.distribution.sol.onetick.com/api/source/show_symbol_name_in_db.html.md)
* [otp.Source.sink](https://docs.pip.distribution.sol.onetick.com/api/source/sink.html.md)
* [otp.Source.skip_bad_tick](https://docs.pip.distribution.sol.onetick.com/api/source/skip_bad_tick.html.md)
* [otp.Source.sort](https://docs.pip.distribution.sol.onetick.com/api/source/sort.html.md)
* [otp.Source.split](https://docs.pip.distribution.sol.onetick.com/api/source/split.html.md)
* [otp.Source.standardized_moment](https://docs.pip.distribution.sol.onetick.com/api/source/standardized_moment.html.md)
* [otp.Source.state_vars](https://docs.pip.distribution.sol.onetick.com/api/source/state_vars.html.md)
* [otp.Source.switch](https://docs.pip.distribution.sol.onetick.com/api/source/switch.html.md)
* [otp.Source.table](https://docs.pip.distribution.sol.onetick.com/api/source/table.html.md)
* [otp.Source.tail (jupyter)](https://docs.pip.distribution.sol.onetick.com/api/source/tail.html.md)
* [otp.Source.throw](https://docs.pip.distribution.sol.onetick.com/api/source/throw.html.md)
* [otp.Source.time_filter](https://docs.pip.distribution.sol.onetick.com/api/source/time_filter.html.md)
* [otp.Source.time_interval_change](https://docs.pip.distribution.sol.onetick.com/api/source/time_interval_change.html.md)
* [otp.Source.time_interval_shift](https://docs.pip.distribution.sol.onetick.com/api/source/time_interval_shift.html.md)
* [otp.Source.to_df](https://docs.pip.distribution.sol.onetick.com/api/source/to_df.html.md)
* [otp.Source.to_graph](https://docs.pip.distribution.sol.onetick.com/api/source/to_graph.html.md)
* [otp.Source.to_otq](https://docs.pip.distribution.sol.onetick.com/api/source/to_otq.html.md)
* [otp.Source.to_symbol_param](https://docs.pip.distribution.sol.onetick.com/api/source/to_symbol_param.html.md)
* [otp.Source.transpose](https://docs.pip.distribution.sol.onetick.com/api/source/transpose.html.md)
* [otp.Source.update](https://docs.pip.distribution.sol.onetick.com/api/source/update.html.md)
* [otp.Source.update_timestamp](https://docs.pip.distribution.sol.onetick.com/api/source/update_timestamp.html.md)
* [otp.Source.value_present](https://docs.pip.distribution.sol.onetick.com/api/source/value_present.html.md)
* [otp.Source.virtual_ob](https://docs.pip.distribution.sol.onetick.com/api/source/virtual_ob.html.md)
* [otp.Source.where](https://docs.pip.distribution.sol.onetick.com/api/source/where.html.md)
* [otp.Source.where_clause](https://docs.pip.distribution.sol.onetick.com/api/source/where_clause.html.md)
* [otp.Source.write](https://docs.pip.distribution.sol.onetick.com/api/source/write.html.md)
* [otp.Source.write_parquet](https://docs.pip.distribution.sol.onetick.com/api/source/write_parquet.html.md)
* [otp.Source.write_text](https://docs.pip.distribution.sol.onetick.com/api/source/write_text.html.md)
