# otp.Source._\_call_\_

#### Source.\_\_call_\_(\*args, \*\*kwargs)

#### Deprecated
Deprecated since version 1.48.3: Use [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run) instead.
