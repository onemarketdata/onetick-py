# otp.Source.exp_w_average

#### Source.exp_w_average(decay, decay_value_type='lambda', running=False, bucket_interval=0, bucket_units=None, bucket_time='end', bucket_end_condition=None, boundary_tick_bucket='new', all_fields=False, group_by=None, groups_to_display='all', end_condition_per_group=False, time_series_type='state_ts')

`EXP_W_AVERAGE` aggregation.

For each bucket, computes the **exponentially weighted average** value of the specified numeric attribute.
Weights of data points in a bucket decrease exponentially in the direction from the most recent tick
to the most aged one, being equal to `exp(-Lambda * N)` for a fixed weight decay value **Lambda**,
where **N** ranges over **0, 1, 2, …** as ticks in reverse order of their arrival are treated.
Once the weights are known, the average is found using the formula `sum(weight*value)/sum(weight)`,
where the sum is computed across all data points.

* **Parameters:**
  * **decay** ([*float*](https://docs.python.org/3/library/functions.html#float)) -- Weight decay. If **decay_value_type** is set to `lambda`,
    **decay** provides the value of the **Lambda** variable in the aforementioned formula.
    Otherwise, if **decay_value_type** is set to `half_life_index`, **decay** specifies the necessary number
    of consecutive ticks, the first one of which would have twice less the weight of the last one.
    The **Lambda** value is then calculated using this number.
  * **decay_value_type** (*Literal* *[* *'lambda'* *,*  *'half_life_index'* *]* *,* *default=lambda*) -- The decay value can specified either directly or indirectly, controlled respectively by
    **lambda** and **half_life_index** values of this parameter.
  * **running** ([*bool*](https://docs.python.org/3/library/functions.html#bool) *,* *default=False*) -- 

    See [Aggregation buckets guide](../aggregations/root.md#buckets-guide) to see examples of how this parameter works.

    Specifies if the aggregation will be calculated as a sliding window.
    `running` and `bucket_interval` parameters determines when new buckets are created.
    * `running` = True

      aggregation will be calculated in a sliding window.
      * `bucket_interval` = N (N > 0)

        Window size will be N. Output tick will be generated when tick "enter" window (**arrival event**) and
        when "exit" window (**exit event**)
      * `bucket_interval` = 0

        Left boundary of window will be set to query start time. For each tick aggregation will be calculated in
        the interval [start_time; tick_t] from query start time to the tick's timestamp (inclusive).
    * `running` = False (default)

      buckets partition the [query start time, query end time) interval into non-overlapping intervals
      of size `bucket_interval` (with the last interval possibly of a smaller size).
      If `bucket_interval` is set to **0** a single bucket for the entire interval is created.

      Note that in non-running mode OneTick unconditionally divides the whole time interval
      into specified number of buckets.
      It means that you will always get this specified number of ticks in the result,
      even if you have less ticks in the input data.

    Default: False
  * **bucket_interval** (int or float or [`Operation`](../operation/root.md#onetick.py.Operation) or [`OnetickParameter`](../misc/param.md#onetick.py.core.column_operations.base.OnetickParameter) or [`symbol parameter`](Symbol.md#onetick.py.core._source.symbol.SymbolType.__getitem__) or [datetime offset object](../datetime/offsets/root.md#id1), default=0) -- 

    Determines the length of each bucket (units depends on `bucket_units`).

    If [`Operation`](../operation/root.md#onetick.py.Operation) of bool type is passed, acts as `bucket_end_condition`.

    Bucket interval can also be set as a *float* value
    if `bucket_units` is set to *seconds*.
    Note that values less than 0.001 (1 millisecond) are not supported.

    Bucket interval can be set via some of the [datetime offset objects](../datetime/offsets/root.md#id1):
    [`otp.Milli`](../datetime/offsets/milli.md#onetick.py.Milli), [`otp.Second`](../datetime/offsets/second.md#onetick.py.Second),
    [`otp.Minute`](../datetime/offsets/minute.md#onetick.py.Minute), [`otp.Hour`](../datetime/offsets/hour.md#onetick.py.Hour),
    [`otp.Day`](../datetime/offsets/day.md#onetick.py.Day), [`otp.Month`](../datetime/offsets/month.md#onetick.py.Month).
    In this case you could omit setting `bucket_units` parameter.

    Bucket interval can also be set with integer [`OnetickParameter`](../misc/param.md#onetick.py.core.column_operations.base.OnetickParameter)
    or [`symbol parameter`](Symbol.md#onetick.py.core._source.symbol.SymbolType.__getitem__).
  * **bucket_units** (*Optional* *[**Literal* *[* *'seconds'* *,*  *'ticks'* *,*  *'days'* *,*  *'months'* *,*  *'flexible'* *]* *]* *,* *default=None*) -- 

    Set bucket interval units.

    By default, if `bucket_units` and `bucket_end_condition` not specified, set to **seconds**.
    If `bucket_end_condition` specified, then `bucket_units` set to **flexible**.

    If set to **flexible** then `bucket_end_condition` must be set.

    Note that **seconds** bucket unit doesn't take into account daylight-saving time of the timezone,
    so you may not get expected results when using, for example, 24 \* 60 \* 60 seconds as bucket interval.
    In such case use **days** bucket unit instead.
    See example in [`onetick.py.agg.sum()`](../aggregations/sum.md#onetick.py.agg.sum).
  * **bucket_time** (*Literal* *[* *'start'* *,*  *'end'* *]* *,* *default=end*) -- 

    Control output timestamp.
    * **start**

      the timestamp  assigned to the bucket is the start time of the bucket.
    * **end**

      the timestamp assigned to the bucket is the end time of the bucket.
  * **bucket_end_condition** (*condition* *,* *default=None*) -- 

    An expression that is evaluated on every tick. If it evaluates to "True", then a new bucket is created.
    This parameter is only used if `bucket_units` is set to "flexible".

    Also can be set via `bucket_interval` parameter by passing [`Operation`](../operation/root.md#onetick.py.Operation) object.
  * **boundary_tick_bucket** (*Literal* *[* *'new'* *,*  *'previous'* *]* *,* *default=new*) -- 

    Controls boundary tick ownership.
    * **previous**

      A tick on which `bucket_end_condition` evaluates to "true" belongs to the bucket being closed.
    * **new**

      tick belongs to the new bucket.

    This parameter is only used if `bucket_units` is set to "flexible"
  * **all_fields** (*Union* *[*[*bool*](https://docs.python.org/3/library/functions.html#bool) *,* [*str*](https://docs.python.org/3/library/stdtypes.html#str) *]* *,* *default=False*) -- 

    See [Aggregation buckets guide](../aggregations/root.md#buckets-guide) to see examples of how this parameter works.
    * `all_fields` = True

      output ticks include all fields from the input ticks
      * `running` = True

      an output tick is created only when a tick enters the sliding window
      * `running` = False

      fields of first tick in bucket will be used
    * `all_fields` = False and `running` = True

      output ticks are created when a tick enters or leaves the sliding window.
    * `all_fields` = "when_ticks_exit_window" and `running` = True

      output ticks are generated only for exit events, but all attributes from the exiting tick are copied over
      to the output tick and the aggregation is added as another attribute.
  * **group_by** ([*list*](https://docs.python.org/3/library/stdtypes.html#list) *,* [*str*](https://docs.python.org/3/library/stdtypes.html#str) *or* *expression* *,* *default=None*) -- When specified, each bucket is broken further into additional sub-buckets based on specified field values.
    If [`Operation`](../operation/root.md#onetick.py.Operation) is used then GROUP_{i} column is added. Where i is index in group_by list.
    For example, if Operation is the only element in `group_by` list then GROUP_0 field will be added.
  * **groups_to_display** (*Literal* *[* *'all'* *,*  *'previous'* *]* *,* *default=all*) -- Specifies for which sub-buckets (groups) ticks should be shown for each bucket interval.
    By default **all** groups are shown at the end of each bucket interval.
    If this parameter is set to **event_in_last_bucket**, only the groups that received at least one tick
    within a given bucket interval are shown.
  * **end_condition_per_group** ([*bool*](https://docs.python.org/3/library/functions.html#bool) *,* *default=False*) -- 

    Controls application of `bucket_end_condition` in groups.
    * `end_condition_per_group` = True

      `bucket_end_condition` is applied only to the group defined by `group_by`
    * `end_condition_per_group` = False

      `bucket_end_condition` applied across all groups

    This parameter is only used if `bucket_units` is set to "flexible".

    When set to True, applies to all bucketing conditions. Useful, for example, if you need to specify `group_by`,
    and you want to group items first, and create buckets after that.
  * **time_series_type** (*Literal* *[* *'event_ts'* *,*  *'state_ts'* *]* *,* *default=state_ts*) -- 

    Controls initial value for each bucket
    * **event_ts**

      only ticks from current bucket used for calculations
    * **state_ts**
      * if there is a tick in bucket with timestamp = bucket start

        only ticks in bucket used for calculation max value
      * else

        latest tick from previous bucket included in current bucket
* **Return type:**
  [Source](root.md#onetick.py.Source)

### Examples

Basic example

```pycon
>>> data = otp.Ticks({'A': [1.0, 2.0, 3.0, 3.0, 4.0]})
>>> data = data.exp_w_average('A', decay=2, bucket_interval=2, bucket_units='ticks')
>>> otp.run(data)
                     Time         A
0 2003-12-01 00:00:00.001  1.880797
1 2003-12-01 00:00:00.003  2.984124
2 2003-12-04 00:00:00.000  3.880797
```

You can switch to `half_life_index` as `decay_value_type`

```pycon
>>> data = otp.Ticks({'A': [1.0, 2.0, 3.0, 3.0, 4.0]})
>>> data = data.exp_w_average(
...     'A', decay=2, decay_value_type='half_life_index', bucket_interval=2, bucket_units='ticks',
... )
>>> otp.run(data)
                     Time         A
0 2003-12-01 00:00:00.001  1.585786
1 2003-12-01 00:00:00.003  2.773459
2 2003-12-04 00:00:00.000  3.585786
```

#### SEE ALSO
**EXP_W_AVERAGE** OneTick event processor
