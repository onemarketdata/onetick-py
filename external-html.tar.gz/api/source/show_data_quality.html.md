# otp.Source.show_data_quality

#### Source.show_data_quality(inplace=False)

This method shows data quality events within the interval of the query.

* **Parameters:**
  * **inplace** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- The flag controls whether operation should be applied inplace or not.
    If `inplace=True`, then it returns nothing.
    Otherwise, method returns a new modified object.
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [`Source`](root.md#onetick.py.Source) or `None`

### Examples

By default data quality events are not showed, use this method to see them:

```pycon
>>> data = otp.Ticks({'A': [1, 2, 3]})
>>> data = data.insert_data_quality_event('OK')
>>> data = data.show_data_quality()
>>> otp.run(data)
                     Time  DATA_QUALITY_TYPE DATA_QUALITY_NAME
0 2003-12-01 00:00:00.000                  0                OK
1 2003-12-01 00:00:00.001                  0                OK
2 2003-12-01 00:00:00.002                  0                OK
```

#### SEE ALSO
**SHOW_DATA_QUALITY** OneTick event processor
<br/>
[`insert_data_quality_event()`](insert_data_quality_event.md#onetick.py.Source.insert_data_quality_event)
<br/>
[`intercept_data_quality()`](intercept_data_quality.md#onetick.py.Source.intercept_data_quality)
<br/>
