# otp.Source.table

#### Source.table(inplace=False, strict=True, \*\*schema)

Set the OneTick and python schemas levels according to the `schema`
parameter. The `schema` should contain either (field_name -> type) pairs
or (field_name -> default value) pairs; `None` means no specified type, and
OneTick considers it's as a double type.

Resulting ticks have the same order as in the `schema`. If only partial fields
are specified (i.e. when the `strict=False`) then fields from the `schema` have
the most left position.

* **Parameters:**
  * **inplace** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- The flag controls whether operations should be applied inplace
  * **strict** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If set to `False`, all fields present in an input tick will be present in the output tick.
    If `True`, then only fields specified in the `schema`.
  * **schema** -- field_name -> type or field_name -> default value pairs that should be applied on the source.
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))
* **Return type:**
  [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) or `None`

### Examples

Selection case

```pycon
>>> data = otp.Ticks(X1=[1, 2, 3],
...                  X2=[3, 2, 1],
...                  A1=["A", "A", "A"])
>>> data = data.table(X2=int, A1=str)
>>> otp.run(data)
                     Time  X2 A1
0 2003-12-01 00:00:00.000   3  A
1 2003-12-01 00:00:00.001   2  A
2 2003-12-01 00:00:00.002   1  A
```

Defining default values case (note the order)

```pycon
>>> data = otp.Ticks(X=[1, 2, 3])
>>> data = data.table(Y=0.5, strict=False)
>>> otp.run(data)
                     Time   Y   X
0 2003-12-01 00:00:00.000  0.5  1
1 2003-12-01 00:00:00.001  0.5  2
2 2003-12-01 00:00:00.002  0.5  3
```

#### SEE ALSO
[`Source.schema`](https://docs.pip.distribution.sol.onetick.com/api/source/schema.html.md#onetick.py.Source.schema)
<br/>
[`__getitem__()`](https://docs.pip.distribution.sol.onetick.com/api/source/__getitem__.html.md#onetick.py.Source.__getitem__): the table shortcut
<br/>
**TABLE** OneTick event processor
<br/>
