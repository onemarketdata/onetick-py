# otp.Source.if_else

#### Source.if_else(condition, if_expr, else_expr)

Shortcut for [`apply()`](apply.md#onetick.py.Source.apply) with lambda if-else expression

* **Parameters:**
  * **condition** ([`Operation`](../operation/root.md#onetick.py.Operation)) -- 
    - condition for matching ticks
  * **if_expr** ([`Operation`](../operation/root.md#onetick.py.Operation), value) -- 
    - value or Operation to set if condition is true
  * **else_expr** ([`Operation`](../operation/root.md#onetick.py.Operation), value) -- 
    - value or Operation to set if condition is false
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [Column](../operation/root.md#onetick.py.Column)

### Examples

Basic example of apply if-else to a tick flow:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3])
>>> data['Y'] = data.if_else(data['X'] > 2, 1, 0)
>>> otp.run(data)
                     Time  X  Y
0 2003-12-01 00:00:00.000  1  0
1 2003-12-01 00:00:00.001  2  0
2 2003-12-01 00:00:00.002  3  1
```

You can also set column value via [`Operation`](../operation/root.md#onetick.py.Operation):

```pycon
>>> data = otp.Ticks(X=[1, 2, 3])
>>> data['Y'] = data.if_else(data['X'] > 2, data['X'] * 2, 0)
>>> otp.run(data)
                     Time  X  Y
0 2003-12-01 00:00:00.000  1  0
1 2003-12-01 00:00:00.001  2  0
2 2003-12-01 00:00:00.002  3  6
```

#### SEE ALSO
[`onetick.py.Source.apply()`](apply.md#onetick.py.Source.apply)
