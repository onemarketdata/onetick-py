# otp.Source.get_name

#### Source.get_name(remove_invalid_symbols=False)

Returns source name.

* **Parameters:**
  **remove_invalid_symbols** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If True, all characters not supported in query names in .otq file will be replaced,
  because only alphanumeric, minus and underscore characters are supported in query names.
* **Return type:**
  [str](https://docs.python.org/3/library/stdtypes.html#str) | None

#### SEE ALSO
[`set_name()`](set_name.md#onetick.py.Source.set_name)
