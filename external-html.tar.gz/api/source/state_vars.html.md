# otp.Source.state_vars

#### *property* Source.state_vars *: StateVars*

Provides access to state variables

* **Returns:**
  **State Variables** -- State variables, you can access one with its name.
* **Return type:**
  [dict](https://docs.python.org/3/library/stdtypes.html#dict)[[str](https://docs.python.org/3/library/stdtypes.html#str), state variable]

#### SEE ALSO
[State Variables](../../static/getting_started/variables_and_data_structures.html#variables-and-data-structures)
<br/>
**DECLARE_STATE_VARIABLES** OneTick event processor
<br/>
