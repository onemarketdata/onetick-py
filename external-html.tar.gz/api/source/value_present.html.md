# otp.Source.value_present

#### Source.value_present(field, values, discard_on_match=False, inplace=False)

Propagates ticks based on whether the value of the `field` contains one of the list of `values`.

* **Parameters:**
  * **field** (str, [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column)) -- Name of the field (must be present in the input tick descriptor).
  * **values** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* [*list*](https://docs.python.org/3/library/stdtypes.html#list) *[*[*str*](https://docs.python.org/3/library/stdtypes.html#str) *]*) -- A set of values that are searched for in the value of the `field`.
  * **discard_on_match** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- When set to `True` only ticks that did not match the filter are propagated,
    otherwise ticks that satisfy the filter condition are propagated.
  * **inplace** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- The flag controls whether operation should be applied inplace or not.
    If `inplace=True`, then it returns nothing.
    Otherwise, method returns a new modified object.
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))
* **Return type:**
  [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) or `None`

### Examples

Select ticks that have specified values in field A:

```pycon
>>> data = otp.Ticks(A=[1, 2, 3, 4, 5])
>>> data = data.value_present(field='A', values=[2, 3])
>>> otp.run(data)
                     Time  A
0 2003-12-01 00:00:00.001  2
1 2003-12-01 00:00:00.002  3
```

Use parameter `discard_on_match` to filter values *out*:

```pycon
>>> data = otp.Ticks(A=[1, 2, 3, 4, 5])
>>> data = data.value_present(field='A', values=[2, 3], discard_on_match=True)
>>> otp.run(data)
                     Time  A
0 2003-12-01 00:00:00.000  1
1 2003-12-01 00:00:00.003  4
2 2003-12-01 00:00:00.004  5
```

#### SEE ALSO
**VALUE_PRESENT** OneTick event processor
[`onetick.py.Operation.isin()`](https://docs.pip.distribution.sol.onetick.com/api/operation/isin.html.md#onetick.py.Operation.isin)
