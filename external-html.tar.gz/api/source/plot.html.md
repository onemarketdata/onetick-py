# otp.Source.plot (jupyter)

#### Source.plot(y, x='Time', kind='line', \*\*kwargs)

Executes the query with known properties and builds a plot resulting dataframe.

Uses the [pandas.DataFrame.plot](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.plot.html) method to plot data.
Other parameters could be specified through the `kwargs`.

* **Parameters:**
  * **x** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Column name for the X axis
  * **y** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Column name for the Y axis
  * **kind** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- The kind of plot
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))

### Examples

```pycon
>>> data = otp.Ticks(X=[1, 2, 3])
>>> data.plot(y='X', kind='bar')  
```
