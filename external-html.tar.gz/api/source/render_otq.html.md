# otp.Source.render_otq

#### Source.render_otq(image_path=None, output_format=None, load_external_otqs=True, view=False, line_limit=(10, 30), parse_eval_from_params=False, render_debug_info=False, debug=False, graphviz_compat_mode=False, font_family=None, font_size=None, \*\*kwargs)

Render current [`Source`](root.md#onetick.py.Source) graph.

* **Parameters:**
  * **image_path** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *None*) -- Path for generated image. If omitted, image will be saved in a temp dir
  * **output_format** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *None*) -- Graphviz rendering format. Default: png.
    If image_path contains one of next extensions, output_format will be set automatically:
    png, svg, dot.
  * **load_external_otqs** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If set to True (default) dependencies from external .otq files (not listed in `path` param)
    will be loaded automatically.
  * **view** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Defines should generated image be shown after render.
  * **line_limit** ([*tuple*](https://docs.python.org/3/library/stdtypes.html#tuple) *[*[*int*](https://docs.python.org/3/library/functions.html#int) *,* [*int*](https://docs.python.org/3/library/functions.html#int) *]* *,* *None*) -- Limit for maximum number of lines and length of some EP parameters strings.
    First param is limit of lines, second - limit of characters in each line.
    If set to None limit disabled.
    If one of tuple values set to zero the corresponding limit disabled.
  * **parse_eval_from_params** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Enable parsing and printing eval sub-queries from EP parameters.
  * **render_debug_info** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Render additional debug information.
  * **debug** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Allow to print stdout or stderr from Graphviz render.
  * **graphviz_compat_mode** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Change internal parameters of result graph for better compatibility with old Graphviz versions.
    Could produce larger and less readable graphs.
  * **font_family** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- 

    Font name

    Default: **Monospace**
  * **font_size** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* [*float*](https://docs.python.org/3/library/functions.html#float) *,* [*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- Font size
  * **kwargs** -- Additional arguments to be passed to [`onetick.py.Source.to_otq()`](to_otq.md#onetick.py.Source.to_otq) method (except
    `file_name`, `file_suffix` and `query_name` parameters)
* **Return type:**
  Path to rendered image

### Examples

```pycon
>>> data = otp.DataSource(db='US_COMP_SAMPLE', tick_type='TRD', symbols='AAPL')  
>>> data1, data2 = data[(data['PRICE'] > 50)]                                    
>>> data = otp.merge([data1, data2])                                             
>>> data.render_otq('./path/to/image.png')                                       
```

![image](static/testing/images/render_otq_3.png)

#### SEE ALSO
[`render_otq`](../misc/render.md#onetick.py.utils.render_otq)
