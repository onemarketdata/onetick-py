# otp.Source._\_setitem_\_

#### Source.\_\_setitem_\_(key, value)

Add new column to the source or update existing one.

* **Parameters:**
  * **key** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- The name of the new or existing column.
  * **value** (int, str, float, [`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`datetime.date`](https://docs.python.org/3/library/datetime.html#datetime.date),             [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column), [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`string`](https://docs.pip.distribution.sol.onetick.com/api/types/string.html.md#onetick.py.string),             [`otp.date`](https://docs.pip.distribution.sol.onetick.com/api/datetime/date.html.md#onetick.py.date), [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime),             [`nsectime`](https://docs.pip.distribution.sol.onetick.com/api/types/nsectime.html.md#onetick.py.nsectime), [`msectime`](https://docs.pip.distribution.sol.onetick.com/api/types/msectime.html.md#onetick.py.msectime)) -- The new value of the column.
  * **self** ([*Source*](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source))

### Examples

```pycon
>>> data = otp.Tick(A='A')
>>> data['D'] = otp.datetime(2022, 2, 2)
>>> data['X'] = 1
>>> data['Y'] = data['X']
>>> data['X'] = 12345
>>> data['Z'] = data['Y'].astype(str) + 'abc'
>>> otp.run(data)
        Time  A          D      X  Y     Z
0 2003-12-01  A 2022-02-02  12345  1  1abc
```

#### SEE ALSO
**ADD_FIELD** OneTick event processor
<br/>
**UPDATE_FIELD** OneTick event processor
<br/>
