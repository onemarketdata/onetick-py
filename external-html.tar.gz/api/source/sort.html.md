# otp.Source.sort

#### Source.sort(by, ascending=True, inplace=False)

Sort ticks by columns.

* **Parameters:**
  * **by** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* [*Column*](../operation/root.md#onetick.py.Column) *or* [*list*](https://docs.python.org/3/library/stdtypes.html#list) *of* *them*) -- Column(s) to sort by. It is possible to pass a list of column, where is the order is important:
    from the left to the right.
  * **ascending** ([*bool*](https://docs.python.org/3/library/functions.html#bool) *or* [*list*](https://docs.python.org/3/library/stdtypes.html#list)) -- Order to sort by. If list of columns is specified, then list of ascending values per column is expected.
    (the [`nan`](../types/nan.md#onetick.py.nan) is the smallest for `float` type fields)
  * **inplace** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- A flag controls whether operation should be applied inplace.
    If `inplace=True`, then it returns nothing. Otherwise method
    returns a new modified object
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  [`Source`](root.md#onetick.py.Source)

### Examples

Single column examples

```pycon
>>> data = otp.Ticks({'X':[     94,   5,   34],
...                   'Y':[otp.nan, 3.1, -0.3]})
>>> data = data.sort(data['X'])
>>> otp.run(data)
                     Time   X    Y
0 2003-12-01 00:00:00.001   5  3.1
1 2003-12-01 00:00:00.002  34 -0.3
2 2003-12-01 00:00:00.000  94  NaN
```

```pycon
>>> data = otp.Ticks({'X':[     94,   5,   34],
...                   'Y':[otp.nan, 3.1, -0.3]})
>>> data = data.sort(data['Y'])
>>> otp.run(data)
                     Time   X    Y
0 2003-12-01 00:00:00.000  94  NaN
1 2003-12-01 00:00:00.002  34 -0.3
2 2003-12-01 00:00:00.001   5  3.1
```

Inplace

```pycon
>>> data = otp.Ticks({'X':[     94,   5,   34],
...                   'Y':[otp.nan, 3.1, -0.3]})
>>> data.sort(data['Y'], inplace=True)
>>> otp.run(data)
                     Time   X    Y
0 2003-12-01 00:00:00.000  94 NaN
1 2003-12-01 00:00:00.002  34 -0.3
2 2003-12-01 00:00:00.001  5   3.1
```

Multiple columns

```pycon
>>> data = otp.Ticks({'X':[  5,   6,   3,   6],
...                   'Y':[1.4, 3.1, 9.1, 5.5]})
>>> data = data.sort([data['X'], data['Y']])
>>> otp.run(data)
                     Time  X    Y
0 2003-12-01 00:00:00.002  3  9.1
1 2003-12-01 00:00:00.000  5  1.4
2 2003-12-01 00:00:00.001  6  3.1
3 2003-12-01 00:00:00.003  6  5.5
```

Ascending/descending control

```pycon
>>> data = otp.Ticks({'X':[     94,   5,   34],
...                   'Y':[otp.nan, 3.1, -0.3]})
>>> data = data.sort(data['X'], ascending=False)
>>> otp.run(data)
                     Time   X    Y
0 2003-12-01 00:00:00.000  94  NaN
1 2003-12-01 00:00:00.002  34 -0.3
2 2003-12-01 00:00:00.001   5  3.1
```

```pycon
>>> data = otp.Ticks({'X':[  5,   6,   3,   6],
...                   'Y':[1.4, 3.1, 9.1, 5.5]})
>>> data = data.sort([data['X'], data['Y']], ascending=[True, False])
>>> otp.run(data)
                     Time  X    Y
0 2003-12-01 00:00:00.002  3  9.1
1 2003-12-01 00:00:00.000  5  1.4
2 2003-12-01 00:00:00.003  6  5.5
3 2003-12-01 00:00:00.001  6  3.1
```

#### SEE ALSO
**ORDER_BY** OneTick event processor
