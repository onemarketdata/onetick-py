# otp.Source.switch

#### Source.switch(expr, cases, default=False)

The method splits data using passed expression for several
outputs by passed cases. This method is an alias for
[`Source.split()`](split.md#onetick.py.Source.split) method.

* **Parameters:**
  * **expr** ([*Operation*](../operation/root.md#onetick.py.Operation)) -- column or column based expression
  * **cases** ([*list*](https://docs.python.org/3/library/stdtypes.html#list)) -- list of values or [`onetick.py.range`](../misc/range.md#onetick.py.range) objects to split by
  * **default** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- `True` adds the default output
  * **self** ([*Source*](root.md#onetick.py.Source))
* **Return type:**
  Outputs according to passed cases, number of outputs is number of cases plus one if `default=True`

### Examples

```pycon
>>> data = otp.Ticks(X=[0.33, -5.1, otp.nan, 9.4])
>>> r1, r2, r3 = data.switch(data['X'], [otp.nan, otp.range(0, 100)], default=True)
>>> otp.run(r1)
                     Time   X
0 2003-12-01 00:00:00.002 NaN
>>> otp.run(r2)
                     Time     X
0 2003-12-01 00:00:00.000  0.33
1 2003-12-01 00:00:00.003  9.40
>>> otp.run(r3)
                     Time    X
0 2003-12-01 00:00:00.001 -5.1
```

#### SEE ALSO
[`Source.split`](split.md#onetick.py.Source.split), [`onetick.py.range`](../misc/range.md#onetick.py.range)

#### SEE ALSO
[`Source.split()`](split.md#onetick.py.Source.split)
<br/>
**SWITCH** OneTick event processor
<br/>
