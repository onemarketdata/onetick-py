# otp.cut

### cut(column, bins, labels=None)

Bin values into discrete intervals (mimics [pandas.cut](https://pandas.pydata.org/docs/reference/api/pandas.cut.html)).

* **Parameters:**
  * **column** ([`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column)) -- Column with numeric data used to build bins.
  * **bins** ([*int*](https://docs.python.org/3/library/functions.html#int) *or* [*list*](https://docs.python.org/3/library/stdtypes.html#list) *[*[*float*](https://docs.python.org/3/library/functions.html#float) *]*) -- 

    When list[float] - defines the bin edges.

    When int - Defines the number of equal-width bins in the range of x.
  * **labels** ([*list*](https://docs.python.org/3/library/stdtypes.html#list) *[*[*str*](https://docs.python.org/3/library/stdtypes.html#str) *]*) -- Labels used to name resulting bins.
    If not set, bins are numeric intervals like (5.0000000000, 7.5000000000].
* **Return type:**
  object that can be set to [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) via [`__setitem__()`](https://docs.pip.distribution.sol.onetick.com/api/source/__setitem__.html.md#onetick.py.Source.__setitem__)

### Examples

```pycon
>>> data = otp.Ticks({"X": [9, 8, 5, 6, 7, 0, ]})
>>> data['bin'] = otp.cut(data['X'], bins=3, labels=['a', 'b', 'c'])
>>> otp.run(data)[['X', 'bin']]
   X bin
0  9   c
1  8   c
2  5   b
3  6   b
4  7   c
5  0   a
```
