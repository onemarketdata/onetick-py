# Functions

## Table Of Contents

* [otp.coalesce](https://docs.pip.distribution.sol.onetick.com/api/functions/coalesce.html.md)
* [otp.cut](https://docs.pip.distribution.sol.onetick.com/api/functions/cut.html.md)
* [otp.format](https://docs.pip.distribution.sol.onetick.com/api/functions/format.html.md)
* [otp.join](https://docs.pip.distribution.sol.onetick.com/api/functions/join.html.md)
* [otp.join_by_time](https://docs.pip.distribution.sol.onetick.com/api/functions/join_by_time.html.md)
* [otp.join_with_aggregated_window](https://docs.pip.distribution.sol.onetick.com/api/functions/join_with_aggregated_window.html.md)
* [otp.merge](https://docs.pip.distribution.sol.onetick.com/api/functions/merge.html.md)
* [otp.corp_actions](https://docs.pip.distribution.sol.onetick.com/api/functions/oqd.html.md)
* [otp.qcut](https://docs.pip.distribution.sol.onetick.com/api/functions/qcut.html.md)
* [otp.functions.save_sources_to_single_file](https://docs.pip.distribution.sol.onetick.com/api/functions/save_sources_to_single_file.html.md)
* [Math functions](https://docs.pip.distribution.sol.onetick.com/api/functions/math/root.html.md)
* [Miscellaneous functions](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/root.html.md)
* [Cache related functions](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/root.html.md)
