# otp.misc.bit_xor

### bit_xor(value1, value2)

Performs the logical XOR operation on each pair of corresponding bits of the parameters.

* **Parameters:**
  * **value1** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **value2** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

Basic example:

```pycon
>>> data = otp.Tick(A=1)
>>> data['XOR'] = otp.bit_xor(0b111, 0b011)
>>> otp.run(data)
        Time  A  XOR
0 2003-12-01  1    4
```

You can also pass [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) as parameter:

```pycon
>>> data = otp.Tick(A=0b001)
>>> data['XOR'] = otp.bit_xor(data['A'], 0b011)
>>> otp.run(data)
        Time  A  XOR
0 2003-12-01  1    2
```

Or use [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation) as parameter:

```pycon
>>> data = otp.Tick(A=0b001)
>>> data['XOR'] = otp.bit_xor(data['A'] * 2, 0b011)
>>> otp.run(data)
        Time  A  XOR
0 2003-12-01  1    1
```
