# otp.misc.bit_not

### bit_not(value)

Performs the logical NOT operation on each bit of the `value`.

* **Parameters:**
  **value** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

Basic example:

```pycon
>>> data = otp.Tick(A=1)
>>> data['NOT'] = otp.bit_not(1)
>>> otp.run(data)
        Time  A  NOT
0 2003-12-01  1   -2
```

You can also pass [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['NOT'] = otp.bit_not(data['A'])
>>> otp.run(data)
        Time  A  NOT
0 2003-12-01  1   -2
```

Or use [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['NOT'] = otp.bit_not(data['A'] * 2)
>>> otp.run(data)
        Time  A  NOT
0 2003-12-01  1   -3
```
