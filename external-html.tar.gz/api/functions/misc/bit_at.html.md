# otp.misc.bit_at

### bit_at(value, index)

Return bit from `value` at `index` position from the end (zero-based).

* **Parameters:**
  * **value** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **index** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

Basic example:

```pycon
>>> data = otp.Tick(A=1)
>>> data['AT'] = otp.bit_at(0b0010, 1)
>>> otp.run(data)
        Time  A  AT
0 2003-12-01  1   1
```

You can also pass [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) as parameter:

```pycon
>>> data = otp.Tick(A=0b0001)
>>> data['AT'] = otp.bit_at(data['A'], 0)
>>> otp.run(data)
        Time  A  AT
0 2003-12-01  1   1
```

Or use [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation) as parameter:

```pycon
>>> data = otp.Tick(A=0b0001)
>>> data['AT'] = otp.bit_at(data['A'] * 2, 0)
>>> otp.run(data)
        Time  A  AT
0 2003-12-01  1   0
```
