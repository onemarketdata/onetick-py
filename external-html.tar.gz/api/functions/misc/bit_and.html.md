# otp.misc.bit_and

### bit_and(value1, value2)

Performs the logical AND operation on each pair of corresponding bits of the parameters.

* **Parameters:**
  * **value1** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **value2** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

Basic example:

```pycon
>>> data = otp.Tick(A=1)
>>> data['AND'] = otp.bit_and(2, 3)
>>> otp.run(data)
        Time  A  AND
0 2003-12-01  1    2
```

You can also pass [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['AND'] = otp.bit_and(data['A'], 1)
>>> otp.run(data)
        Time  A  AND
0 2003-12-01  1    1
```

Or use [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['AND'] = otp.bit_and(data['A'] * 2, 3)
>>> otp.run(data)
        Time  A  AND
0 2003-12-01  1    2
```
