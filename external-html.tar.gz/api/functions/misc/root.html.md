# Miscellaneous functions

## Table Of Contents

* [otp.misc.bit_and](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/bit_and.html.md)
* [otp.misc.bit_at](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/bit_at.html.md)
* [otp.misc.bit_not](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/bit_not.html.md)
* [otp.misc.bit_or](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/bit_or.html.md)
* [otp.misc.bit_xor](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/bit_xor.html.md)
* [otp.misc.get_onetick_version](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/get_onetick_version.html.md)
* [otp.misc.get_symbology_mapping](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/get_symbology_mapping.html.md)
* [otp.misc.get_username](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/get_username.html.md)
* [otp.misc.hash_code](https://docs.pip.distribution.sol.onetick.com/api/functions/misc/hash_code.html.md)
