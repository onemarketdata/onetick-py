# Miscellaneous functions
