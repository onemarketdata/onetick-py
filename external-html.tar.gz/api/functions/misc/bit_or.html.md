# otp.misc.bit_or

### bit_or(value1, value2)

Performs the logical OR operation on each pair of corresponding bits of the parameters.

* **Parameters:**
  * **value1** (int, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
  * **value2** (int, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
* **Return type:**
  [`Operation`](../../operation/root.md#onetick.py.Operation)

### Examples

Basic example:

```pycon
>>> data = otp.Tick(A=1)
>>> data['OR'] = otp.bit_or(2, 1)
>>> otp.run(data)
        Time  A  OR
0 2003-12-01  1   3
```

You can also pass [`Column`](../../operation/root.md#onetick.py.Column) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['OR'] = otp.bit_or(data['A'], 0)
>>> otp.run(data)
        Time  A  OR
0 2003-12-01  1   1
```

Or use [`Operation`](../../operation/root.md#onetick.py.Operation) as parameter:

```pycon
>>> data = otp.Tick(A=1)
>>> data['OR'] = otp.bit_or(data['A'] * 2, 3)
>>> otp.run(data)
        Time  A  OR
0 2003-12-01  1   3
```
