# Math functions

See also: [Math operations](../../operation/math/root.md#id1)
