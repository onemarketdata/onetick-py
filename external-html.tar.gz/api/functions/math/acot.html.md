# otp.math.acot

### acot(value)

Returns the value of inverse trigonometric function arccot.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['ACOT'] = otp.math.acot(1).round(4)  # should return pi/4 ~ 0.7854
>>> otp.run(data)
        Time  A    ACOT
0 2003-12-01  1  0.7854
```

otp.math.arccot() is the alias for otp.math.acot():

```pycon
>>> data = otp.Tick(A=1)
>>> data['ACOT'] = otp.math.arccot(1).round(4)
>>> otp.run(data)
        Time  A    ACOT
0 2003-12-01  1  0.7854
```

#### SEE ALSO
[`onetick.py.math.pi()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/pi.html.md#onetick.py.math.pi), [`onetick.py.math.cot()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/cot.html.md#onetick.py.math.cot)
