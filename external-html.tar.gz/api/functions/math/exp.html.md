# otp.math.exp

### exp(value)

Compute the natural exponent of the `value`.

* **Parameters:**
  **value** (int, float, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
* **Return type:**
  [`Operation`](../../operation/root.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['E'] = otp.math.exp(1)
>>> otp.run(data)
        Time  A         E
0 2003-12-01  1  2.718282
```

#### SEE ALSO
[`onetick.py.math.ln()`](ln.md#onetick.py.math.ln)
