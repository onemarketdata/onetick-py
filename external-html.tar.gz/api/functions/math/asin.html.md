# otp.math.asin

### asin(value)

Returns the value of inverse trigonometric function arcsin.

* **Parameters:**
  **value** (int, float, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
* **Return type:**
  [`Operation`](../../operation/root.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['ASIN'] = otp.math.asin(1).round(4)  # should return pi/2 ~ 1.5708
>>> otp.run(data)
        Time  A    ASIN
0 2003-12-01  1  1.5708
```

otp.math.arcsin() is the alias for otp.math.asin():

```pycon
>>> data = otp.Tick(A=1)
>>> data['ASIN'] = otp.math.arcsin(1).round(4)
>>> otp.run(data)
        Time  A    ASIN
0 2003-12-01  1  1.5708
```

#### SEE ALSO
[`onetick.py.math.pi()`](pi.md#onetick.py.math.pi), [`onetick.py.math.sin()`](sin.md#onetick.py.math.sin)
