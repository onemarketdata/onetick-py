# otp.math.ln

### ln(value)

Compute the natural logarithm of the `value`.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['LN'] = otp.math.ln(2.718282)
>>> otp.run(data)
        Time  A   LN
0 2003-12-01  1  1.0
```

#### SEE ALSO
[`onetick.py.math.exp()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/exp.html.md#onetick.py.math.exp)
