# otp.math.sqrt

### sqrt(value)

Compute the square root of the `value`.

* **Parameters:**
  **value** (int, float, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
* **Return type:**
  [`Operation`](../../operation/root.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['SQRT'] = otp.math.sqrt(4)
>>> otp.run(data)
        Time  A  SQRT
0 2003-12-01  1   2.0
```
