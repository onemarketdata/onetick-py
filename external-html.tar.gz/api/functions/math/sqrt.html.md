# otp.math.sqrt

### sqrt(value)

Compute the square root of the `value`.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['SQRT'] = otp.math.sqrt(4)
>>> otp.run(data)
        Time  A  SQRT
0 2003-12-01  1   2.0
```
