# otp.math.rand

### rand(min_value, max_value, seed=None)

Returns a pseudo-random value in the range between `min_value` and `max_value` (both inclusive).
If `seed` is not specified, the function produces different values each time a query is invoked.
If `seed` is specified, for this seed the function produces the same sequence of values
each time a query is invoked.

* **Parameters:**
  * **min_value** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **max_value** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **seed** (int, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['RAND'] = otp.math.rand(1, 1000)
>>> otp.run(data)  
        Time  A  RAND
0 2003-12-01  1   155
```
