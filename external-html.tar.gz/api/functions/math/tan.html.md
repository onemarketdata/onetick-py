# otp.math.tan

### tan(value)

Returns the value of trigonometric function tan for the given `value` number expressed in radians.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['TAN'] = otp.math.tan(otp.math.pi() / 4)
>>> otp.run(data)
        Time  A  TAN
0 2003-12-01  1  1.0
```

#### SEE ALSO
[`onetick.py.math.pi()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/pi.html.md#onetick.py.math.pi), [`onetick.py.math.atan()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/atan.html.md#onetick.py.math.atan)
