# otp.math.floor

### floor(value)

Returns a float value representing the largest number that is less than or equal to the `value`.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

#### NOTE
Rounding [`otp.nan`](https://docs.pip.distribution.sol.onetick.com/api/types/nan.html.md#onetick.py.nan) returns NaN
and rounding [`otp.inf`](https://docs.pip.distribution.sol.onetick.com/api/types/inf.html.md#onetick.py.inf) returns Infinity.

### Examples

```pycon
>>> data = otp.Ticks(A=[-1.7, -1.5, -1.2, -1, 0 , 1, 1.2, 1.5, 1.7, -otp.inf, otp.inf, otp.nan])
>>> data['FLOOR'] = otp.math.floor(data['A'])
>>> otp.run(data)
                      Time     A  FLOOR
0  2003-12-01 00:00:00.000  -1.7   -2.0
1  2003-12-01 00:00:00.001  -1.5   -2.0
2  2003-12-01 00:00:00.002  -1.2   -2.0
3  2003-12-01 00:00:00.003  -1.0   -1.0
4  2003-12-01 00:00:00.004   0.0    0.0
5  2003-12-01 00:00:00.005   1.0    1.0
6  2003-12-01 00:00:00.006   1.2    1.0
7  2003-12-01 00:00:00.007   1.5    1.0
8  2003-12-01 00:00:00.008   1.7    1.0
9  2003-12-01 00:00:00.009  -inf   -inf
10 2003-12-01 00:00:00.010   inf    inf
11 2003-12-01 00:00:00.011   NaN    NaN
```
