# otp.math.acos

### acos(value)

Returns the value of inverse trigonometric function arccos.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['ACOS'] = otp.math.acos(-1).round(4)  # should return pi ~ 3.1416
>>> otp.run(data)
        Time  A    ACOS
0 2003-12-01  1  3.1416
```

otp.math.arccos() is the alias for otp.math.acos():

```pycon
>>> data = otp.Tick(A=1)
>>> data['ACOS'] = otp.math.arccos(-1).round(4)
>>> otp.run(data)
        Time  A    ACOS
0 2003-12-01  1  3.1416
```

#### SEE ALSO
[`onetick.py.math.pi()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/pi.html.md#onetick.py.math.pi), [`onetick.py.math.cos()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/cos.html.md#onetick.py.math.cos)
