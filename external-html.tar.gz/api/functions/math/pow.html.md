# otp.math.pow

### pow(base, exponent)

Compute the `base` to the power of the `exponent`.

* **Parameters:**
  * **base** (int, float, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
  * **exponent** (int, float, [`Operation`](../../operation/root.md#onetick.py.Operation), [`Column`](../../operation/root.md#onetick.py.Column))
* **Return type:**
  [`Operation`](../../operation/root.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=2)
>>> data['RES'] = otp.math.pow(data['A'], 10)
>>> otp.run(data)
        Time  A     RES
0 2003-12-01  2  1024.0
```
