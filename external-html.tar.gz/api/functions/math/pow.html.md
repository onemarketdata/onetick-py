# otp.math.pow

### pow(base, exponent)

Compute the `base` to the power of the `exponent`.

* **Parameters:**
  * **base** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **exponent** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=2)
>>> data['RES'] = otp.math.pow(data['A'], 10)
>>> otp.run(data)
        Time  A     RES
0 2003-12-01  2  1024.0
```
