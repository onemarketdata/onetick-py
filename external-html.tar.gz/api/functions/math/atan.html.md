# otp.math.atan

### atan(value)

Returns the value of inverse trigonometric function arctan.

* **Parameters:**
  **value** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=1)
>>> data['ATAN'] = otp.math.atan(1).round(4)  # should return pi/4 ~ 0.7854
>>> otp.run(data)
        Time  A    ATAN
0 2003-12-01  1  0.7854
```

otp.math.arctan() is the alias for otp.math.atan():

```pycon
>>> data = otp.Tick(A=1)
>>> data['ATAN'] = otp.math.arctan(1).round(4)
>>> otp.run(data)
        Time  A    ATAN
0 2003-12-01  1  0.7854
```

#### SEE ALSO
[`onetick.py.math.pi()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/pi.html.md#onetick.py.math.pi), [`onetick.py.math.tan()`](https://docs.pip.distribution.sol.onetick.com/api/functions/math/tan.html.md#onetick.py.math.tan)
