# otp.math.gcd

### gcd(value1, value2)

Computes the greatest common divisor between `value1` and `value2`.

* **Parameters:**
  * **value1** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **value2** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=99)
>>> data['GCD'] = otp.math.gcd(data['A'], 72)
>>> otp.run(data)
        Time   A  GCD
0 2003-12-01  99    9
```
