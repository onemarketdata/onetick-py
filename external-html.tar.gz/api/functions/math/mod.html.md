# otp.math.mod

### mod(value1, value2)

Computes the remainder from dividing `value1` by `value2`.

* **Parameters:**
  * **value1** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
  * **value2** (int, float, [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation), [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column))
* **Return type:**
  [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Tick(A=100)
>>> data['MOD'] = otp.math.mod(data['A'], 72)
>>> otp.run(data)
        Time    A  MOD
0 2003-12-01  100   28
```
