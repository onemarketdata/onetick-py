# Cache related functions
