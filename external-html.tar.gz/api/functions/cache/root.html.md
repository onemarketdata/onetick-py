# Cache related functions

## Table Of Contents

* [otp.create_cache](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/create_cache.html.md)
* [otp.delete_cache](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/delete_cache.html.md)
* [otp.modify_cache_config](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/modify_cache_config.html.md)
