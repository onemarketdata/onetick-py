# otp.delete_cache

### delete_cache(cache_name, apply_to_entire_cache=True, per_cache_otq_params=None, tick_type='ANY', symbol=None, db=None)

Delete cache via DELETE_CACHE EP

* **Parameters:**
  * **cache_name** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Name of the cache to be deleted.
  * **apply_to_entire_cache** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- When set to `True` deletes the cache for all symbols and time intervals.
  * **per_cache_otq_params** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict)) -- Deletes cache that have been associated with this OTQ parameters during its creation.
    Value of this parameter should be equal to the value of `otq_params` of
    `<onetick.py.create_cache>()`.
  * **tick_type** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Tick type.
  * **symbol** (str, list of str, list of otq.Symbol, [`onetick.py.Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source), [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html), optional) -- `symbols` parameter of `otp.run()`.
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Database.

### Examples

Simple cache deletion

```pycon
>>> otp.delete_cache(  
...    cache_name="some_cache", tick_type="TRD", symbol="SYM", db="LOCAL",
... )
```

#### SEE ALSO
**DELETE_CACHE** OneTick event processor
<br/>
[`onetick.py.ReadCache`](https://docs.pip.distribution.sol.onetick.com/api/sources/read_cache.html.md#onetick.py.ReadCache)
<br/>
[`onetick.py.create_cache()`](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/create_cache.html.md#onetick.py.create_cache)
<br/>
