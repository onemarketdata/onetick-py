# otp.modify_cache_config

### modify_cache_config(cache_name, param_name, param_value, tick_type='ANY', symbol=None, db=None)

Modify cache configuration via MODIFY_CACHE_CONFIG EP

* **Parameters:**
  * **cache_name** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Name of the cache to be deleted.
  * **param_name** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- 

    The name of the configuration parameter to be changed.
    Supported parameters:
    * `inheritability`
    * `time_granularity`
    * `time_granularity_units`
    * `timezone`
    * `allow_search_to_everyone`
    * `allow_delete_to_everyone`
    * `allow_update_to_everyone`
  * **param_value** (*Any*) -- New value of configuration parameter. Will be converted to string.
  * **tick_type** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Tick type.
  * **symbol** (str, list of str, list of otq.Symbol, [`onetick.py.Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source), [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html), optional) -- `symbols` parameter of `otp.run()`.
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Database.

### Examples

Simple cache config modification

```pycon
>>> otp.modify_cache_config(  
...    cache_name="some_cache",
...    param_name="time_granularity",
...    param_value=3,
...    tick_type="TRD", symbol="SYM", db="LOCAL",
... )
```

#### SEE ALSO
**MODIFY_CACHE_CONFIG** OneTick event processor
<br/>
[`onetick.py.ReadCache`](https://docs.pip.distribution.sol.onetick.com/api/sources/read_cache.html.md#onetick.py.ReadCache)
<br/>
[`onetick.py.create_cache()`](https://docs.pip.distribution.sol.onetick.com/api/functions/cache/create_cache.html.md#onetick.py.create_cache)
<br/>
