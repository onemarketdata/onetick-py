# otp.Empty

### *class* Empty(db=utils.adaptive_to_default, symbol=utils.adaptive_to_default, tick_type=utils.adaptive, start=utils.adaptive, end=utils.adaptive, schema=None, query_parameters=None, \*\*kwargs)

Bases: [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source)

Empty data source

* **Parameters:**
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Name of the database from which to take schema.
  * **symbol** (str, list of str, [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source), [`query`](https://docs.pip.distribution.sol.onetick.com/api/misc/query.html.md#onetick.py.query), [`eval query`](https://docs.pip.distribution.sol.onetick.com/api/misc/eval.html.md#onetick.py.eval)) -- Symbol(s) from which data should be taken.
  * **tick_type** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,*) -- Name of the tick_type from which to take schema.
  * **start** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime),                     [`onetick.py.adaptive`](https://docs.pip.distribution.sol.onetick.com/api/misc/adaptive.html.md#onetick.py.adaptive)) -- Time interval from which the data should be taken.
  * **end** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime),                     [`onetick.py.adaptive`](https://docs.pip.distribution.sol.onetick.com/api/misc/adaptive.html.md#onetick.py.adaptive)) -- Time interval from which the data should be taken.
  * **schema** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict)) -- Schema to use in case db and/or tick_type are not set.
  * **query_parameters** ([`otp.QueryParameters`](https://docs.pip.distribution.sol.onetick.com/api/misc/query_parameters.html.md#onetick.py.QueryParameters)) -- Additional query properties to be set in the resulting .otq file.
    They will be used if they are not overridden by other parameters or in [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run).
  * **kwargs** -- Deprecated. Use `schema` instead.
    Schema to use in case db and/or tick_type are not set.

### Examples

Empty source returns no data:

```pycon
>>> data = otp.Empty()
>>> otp.run(data)
Empty DataFrame
Columns: []
Index: []
```

But we can still define schema if needed:

```pycon
>>> data = otp.Empty(schema={'A': str, 'B': int})
>>> otp.run(data)
Empty DataFrame
Columns: [A, B, Time]
Index: []
>>> data.schema
{'A': <class 'str'>, 'B': <class 'int'>}
```
