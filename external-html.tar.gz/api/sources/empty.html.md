# otp.Empty

### *class* Empty(db=utils.adaptive_to_default, symbol=utils.adaptive_to_default, tick_type=utils.adaptive, start=utils.adaptive, end=utils.adaptive, schema=None, query_parameters=None, \*\*kwargs)

Bases: [`Source`](../source/root.md#onetick.py.Source)

Empty data source

* **Parameters:**
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Name of the database from which to take schema.
  * **symbol** (str, list of str, [`Source`](../source/root.md#onetick.py.Source), [`query`](../misc/query.md#onetick.py.query), [`eval query`](../misc/eval.md#onetick.py.eval)) -- Symbol(s) from which data should be taken.
  * **tick_type** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,*) -- Name of the tick_type from which to take schema.
  * **start** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](../datetime/dt.md#onetick.py.datetime),                     [`onetick.py.adaptive`](../misc/adaptive.md#onetick.py.adaptive)) -- Time interval from which the data should be taken.
  * **end** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](../datetime/dt.md#onetick.py.datetime),                     [`onetick.py.adaptive`](../misc/adaptive.md#onetick.py.adaptive)) -- Time interval from which the data should be taken.
  * **schema** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict)) -- Schema to use in case db and/or tick_type are not set.
  * **query_parameters** ([`otp.QueryParameters`](../misc/query_parameters.md#onetick.py.QueryParameters)) -- Additional query properties to be set in the resulting .otq file.
    They will be used if they are not overridden by other parameters or in [`otp.run`](../run.md#onetick.py.run).
  * **kwargs** -- Deprecated. Use `schema` instead.
    Schema to use in case db and/or tick_type are not set.

### Examples

Empty source returns no data:

```pycon
>>> data = otp.Empty()
>>> otp.run(data)
Empty DataFrame
Columns: []
Index: []
```

But we can still define schema if needed:

```pycon
>>> data = otp.Empty(schema={'A': str, 'B': int})
>>> otp.run(data)
Empty DataFrame
Columns: [A, B, Time]
Index: []
>>> data.schema
{'A': <class 'str'>, 'B': <class 'int'>}
```
