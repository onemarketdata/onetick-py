# otp.Ticks

### *class* Ticks(data=None, symbol=utils.adaptive_to_default, db=utils.adaptive_to_default, start=utils.adaptive, end=utils.adaptive, tick_type=utils.adaptive, timezone_for_time=None, offset=utils.adaptive, query_parameters=None, \*\*inplace_data)

Bases:

Data source that generates ticks.

By default ticks are placed with the 1 millisecond offset from
each other starting from the start of the query interval.

The offset for each tick can be changed using the
special reserved field name `offset`, that specifies the time offset from the query start time.
`offset` can be an integer, [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) object
or [`otp.timedelta`](https://docs.pip.distribution.sol.onetick.com/api/datetime/timedelta.html.md#onetick.py.timedelta).

* **Parameters:**
  * **data** (dict, list or [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html), optional) -- 

    Ticks values
    * `dict` -- <field_name>: <values>
    * `list` -- [[<field_names>], [<first_tick_values>], ..., [<n_tick_values>]]
    * [DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html)

    #### Deprecated
    Deprecated since version 1.178.0.

    * `None` -- `inplace_data` will be used
  * **symbol** (str, list of str, [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source), [`query`](https://docs.pip.distribution.sol.onetick.com/api/misc/query.html.md#onetick.py.query), [`eval query`](https://docs.pip.distribution.sol.onetick.com/api/misc/eval.html.md#onetick.py.eval)) -- Symbol(s) from which data should be taken.
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Database to use for tick generation
  * **start** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime),                     [`onetick.py.adaptive`](https://docs.pip.distribution.sol.onetick.com/api/misc/adaptive.html.md#onetick.py.adaptive)) -- Timestamp for data generation
  * **end** ([`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime),                     [`onetick.py.adaptive`](https://docs.pip.distribution.sol.onetick.com/api/misc/adaptive.html.md#onetick.py.adaptive)) -- Timestamp for data generation
  * **tick_type** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- tick type for data generation
  * **timezone_for_time** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- timezone for data generation
  * **offset** (int, [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) or [`otp.timedelta`](https://docs.pip.distribution.sol.onetick.com/api/datetime/timedelta.html.md#onetick.py.timedelta)             or list of such values or None) -- Specifies the time offset for each tick from the query start time.
    Should be specified as the list of values, one for each tick,
    or as a single value that will be the same for all ticks.
    Special value None will disable changing timestamps for each tick,
    so all timestamps will be set to the query start time.
    Can't be used at the same time with the column offset.
  * **query_parameters** ([`otp.QueryParameters`](https://docs.pip.distribution.sol.onetick.com/api/misc/query_parameters.html.md#onetick.py.QueryParameters)) -- Additional query properties to be set in the resulting .otq file.
    They will be used if they are not overridden by other parameters or in [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run).
  * **\*\*inplace_data** ([*list*](https://docs.python.org/3/library/stdtypes.html#list)) -- <field_name>: list(<field_values>)

### Examples

Pass the data as a dictionary:

```pycon
>>> d = otp.Ticks({'A': [1, 2, 3], 'B': [4, 5, 6]})
>>> otp.run(d)
                     Time  A  B
0 2003-12-01 00:00:00.000  1  4
1 2003-12-01 00:00:00.001  2  5
2 2003-12-01 00:00:00.002  3  6
```

Pass the data using key-value arguments:

```pycon
>>> d = otp.Ticks(A=[1, 2, 3], B=[4, 5, 6])
>>> otp.run(d)
                     Time  A  B
0 2003-12-01 00:00:00.000  1  4
1 2003-12-01 00:00:00.001  2  5
2 2003-12-01 00:00:00.002  3  6
```

Pass the data using list:

```pycon
>>> d = otp.Ticks([['A', 'B'],
...                [1, 4],
...                [2, 5],
...                [3, 6]])
>>> otp.run(d)
                     Time  A  B
0 2003-12-01 00:00:00.000  1  4
1 2003-12-01 00:00:00.001  2  5
2 2003-12-01 00:00:00.002  3  6
```

Pass the data using [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html).
DataFrame should have a `Time` column containing datetime objects.

```pycon
>>> start_datetime = datetime.datetime(2023, 1, 1, 12)
>>> time_array = [start_datetime + otp.Hour(1) + otp.Nano(1)]
>>> a_array = [start_datetime - otp.Day(15) - otp.Nano(7)]
>>> df = pd.DataFrame({'Time': time_array,'A': a_array})
>>> data = otp.Ticks(df)  
>>> otp.run(data, start=start_datetime, end=start_datetime + otp.Day(1))  
                           Time                             A
0 2023-01-01 13:00:00.000000001 2022-12-17 11:59:59.999999993
```

Example with setting `offset` for each tick:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3], offset=[0, otp.Nano(1), 1])
>>> otp.run(data)
                           Time  X
0 2003-12-01 00:00:00.000000000  1
1 2003-12-01 00:00:00.000000001  2
2 2003-12-01 00:00:00.001000000  3
```

Remove the `offset` for all ticks, in this case the timestamp of each tick is set to the start time of the query:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3], offset=None)
>>> otp.run(data)
        Time  X
0 2003-12-01  1
1 2003-12-01  2
2 2003-12-01  3
```

Parameter `offset` allows to set the same value for all ticks:

```pycon
>>> data = otp.Ticks(X=[1, 2, 3], offset=otp.Nano(13))
>>> otp.run(data)
                           Time  X
0 2003-12-01 00:00:00.000000013  1
1 2003-12-01 00:00:00.000000013  2
2 2003-12-01 00:00:00.000000013  3
```

#### SEE ALSO
**TICK_GENERATOR** OneTick event processor
<br/>
**CSV_FILE_LISTING** OneTick event processor
<br/>
[`otp.Tick`](https://docs.pip.distribution.sol.onetick.com/api/sources/tick.html.md#onetick.py.Tick)
<br/>
