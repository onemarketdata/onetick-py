# Sources

## Table Of Contents

* [otp.CSV](https://docs.pip.distribution.sol.onetick.com/api/sources/csv.html.md)
* [otp.DataFile](https://docs.pip.distribution.sol.onetick.com/api/sources/data_file.html.md)
* [otp.DataSource](https://docs.pip.distribution.sol.onetick.com/api/sources/data_source.html.md)
* [otp.Empty](https://docs.pip.distribution.sol.onetick.com/api/sources/empty.html.md)
* [otp.LoadTicksFromDataFrame](https://docs.pip.distribution.sol.onetick.com/api/sources/load_ticks_from_dataframe.html.md)
* [otp.ODBC](https://docs.pip.distribution.sol.onetick.com/api/sources/odbc.html.md)
* [otp.PointInTime](https://docs.pip.distribution.sol.onetick.com/api/sources/point_in_time.html.md)
* [otp.Query](https://docs.pip.distribution.sol.onetick.com/api/sources/query.html.md)
* [otp.ReadCache](https://docs.pip.distribution.sol.onetick.com/api/sources/read_cache.html.md)
* [otp.ReadFromDataFrame](https://docs.pip.distribution.sol.onetick.com/api/sources/read_from_dataframe.html.md)
* [otp.ReadFromKdb](https://docs.pip.distribution.sol.onetick.com/api/sources/read_from_kdb.html.md)
* [otp.ReadParquet](https://docs.pip.distribution.sol.onetick.com/api/sources/read_parquet.html.md)
* [otp.RefData](https://docs.pip.distribution.sol.onetick.com/api/sources/ref_data.html.md)
* [otp.SplitQueryOutputBySymbol](https://docs.pip.distribution.sol.onetick.com/api/sources/split_query_output_by_symbol.html.md)
* [otp.SymbologyMapping](https://docs.pip.distribution.sol.onetick.com/api/sources/symbology_mapping.html.md)
* [otp.Symbols](https://docs.pip.distribution.sol.onetick.com/api/sources/symbols.html.md)
* [otp.Tick](https://docs.pip.distribution.sol.onetick.com/api/sources/tick.html.md)
* [otp.Ticks](https://docs.pip.distribution.sol.onetick.com/api/sources/ticks.html.md)
* [Order book sources](https://docs.pip.distribution.sol.onetick.com/api/sources/order_book/root.html.md)
* [Snapshot sources](https://docs.pip.distribution.sol.onetick.com/api/sources/snapshot/root.html.md)
