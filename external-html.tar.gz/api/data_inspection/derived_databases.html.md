# otp.derived_databases

### derived_databases(context=utils.default, start=None, end=None, selection_criteria='all', db=None, db_discovery_scope='query_host_only', as_table=False, query_properties=None)

Gets available derived databases.

* **Parameters:**
  * **context** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- Context to run the query.
    If not set then default [`context`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.context) is used.
    See [guide about switching contexts](https://docs.pip.distribution.sol.onetick.com/static/getting_started/session.html.md#switching-contexts) for examples.
  * **start** ([`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime), optional) -- 

    If both `start` and `end` are set, then listing databases in this range only.
    Otherwise list databases from all configured time ranges for databases.

    If `db` is set, then
    [`otp.config.default_start_time`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.default_start_time)
    is used by default.
  * **end** ([`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime), optional) -- 

    If both `start` and `end` are set, then listing databases in this range only.
    Otherwise list databases from all configured time ranges for databases.

    If `db` is set, then
    [`otp.config.default_end_time`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.default_end_time) is used by default.
  * **selection_criteria** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Possible values: *all*, *derived_from_current_db*, *direct_children_of_current_db*.
  * **db** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- Specifies database name if `selection_criteria` is set to
    *derived_from_current_db* or *direct_children_of_current_db*.
    Must be set in this case.
    Also specifies symbol name to use when running the query, otherwise
    [`otp.config.default_db`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.default_db) is used.
  * **db_discovery_scope** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- When *query_host_and_all_reachable_hosts* is specified,
    an attempt will be performed to get derived databases from all reachable hosts.
    When *query_host_only* is specified,
    only derived databases from the host on which the query is performed will be returned.
  * **as_table** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If False (default), this function returns a dictionary of database names and database objects.
    If True, returns a [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html) table where each row contains the info for each database.
  * **query_properties** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict) *,* *optional*) -- Query properties passed to [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run),
    such as ONE_TO_MANY_POLICY, ALLOW_GRAPH_REUSE, etc.
* **Returns:**
  * Dict where keys are database names and values are [`DB`](https://docs.pip.distribution.sol.onetick.com/api/data_inspection/db.html.md#onetick.py.db._inspection.DB) objects
  * or [pandas.DataFrame](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.html) object depending on `as_table` parameter.
* **Return type:**
  [dict](https://docs.python.org/3/library/stdtypes.html#dict)[[str](https://docs.python.org/3/library/stdtypes.html#str), [*DB*](https://docs.pip.distribution.sol.onetick.com/api/data_inspection/db.html.md#onetick.py.db._inspection.DB)]

#### SEE ALSO
**SHOW_DERIVED_DB_LIST** OneTick event processor
