# API reference

We assume that the following shortcuts are used in API docs and examples

```default
import onetick.py as otp
from onetick.py.otq import otq
```
