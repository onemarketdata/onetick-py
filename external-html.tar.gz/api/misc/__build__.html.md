# otp._\_build_\_

Get current OneTick build number:

```pycon
>>> otp.__build__  
'20240530120000'
```
