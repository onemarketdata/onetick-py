# otp.utils.TmpFile

### *class* TmpFile(suffix='', name='', clean_up=default, force=False, base_dir=default)

Bases: `File`, [`PathLike`](https://docs.python.org/3/library/os.html#os.PathLike), `CleanUpFinalizer`

Class to create a temporary file.
By default, this file will be deleted automatically after python process exits.
Base path where temporary files are created could be set using the `ONE_TICK_TMP_DIR`.
By default they are created under the `tempfile.gettempdir()` folder.

* **Parameters:**
  * **name** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- name of the temporary file without suffix.
    By default some random name will be generated.
  * **suffix** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- suffix of the name of the temporary file.
  * **clean_up** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- 

    Controls whether this temporary file will be deleted automatically after python process exits.

    By default, the value of current [`otp.Session`](../session/session.md#onetick.py.Session) is used.
    If it's not set, then
    [`otp.config.clean_up_tmp_files`](../config.md#onetick.py.configuration.Config.clean_up_tmp_files) is used.
  * **force** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Rewrite temporary file if it exists and parameter `name` is set.
  * **base_dir** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Absolute path of the directory where temporary file will be created.
    By default, the directory of current [`otp.Session`](../session/session.md#onetick.py.Session) is used.

#### SEE ALSO
The testing framework has a `--keep-generated` flag that controls clean up for all related instances
[onetick-py-test plugin features](../../static/testing/features.md#onetick-py-test-features)
