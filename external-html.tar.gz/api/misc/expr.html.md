# otp.expr

### *class* Expr(operation)

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

EP parameter's value can be set to an expression.
Expressions are evaluated before parameters are actually passed to event processors.

#### SEE ALSO
[`onetick.py.Operation.expr`](../operation/expr.md#onetick.py.Operation.expr)
