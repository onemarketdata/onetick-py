# otp.expr

### *class* Expr(operation)

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

EP parameter's value can be set to an expression.
Expressions are evaluated before parameters are actually passed to event processors.

#### SEE ALSO
[`onetick.py.Operation.expr`](https://docs.pip.distribution.sol.onetick.com/api/operation/expr.html.md#onetick.py.Operation.expr)
