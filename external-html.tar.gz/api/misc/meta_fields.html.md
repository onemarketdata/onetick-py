# otp.meta_fields

### *class* MetaFields

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

OneTick defines several pseudo-columns that can be treated as if they were columns of every tick.

These columns can be accessed directly via [`onetick.py.Source.__getitem__()`](https://docs.pip.distribution.sol.onetick.com/api/source/__getitem__.html.md#onetick.py.Source.__getitem__) method.

But in case they are used in [`Expr`](https://docs.pip.distribution.sol.onetick.com/api/misc/expr.html.md#onetick.py.core.column_operations.base.Expr)
they can be accessed via `onetick.py.Source.meta_fields`.

### Examples

Accessing pseudo-fields as columns or as class properties

```pycon
>>> data = otp.Tick(A=1)
>>> data['X'] = data['_START_TIME']
>>> data['Y'] = otp.Source.meta_fields['_TIMEZONE']
>>> otp.run(data, start=otp.dt(2003, 12, 2), timezone='GMT')
        Time  A          X    Y
0 2003-12-02  1 2003-12-02  GMT
```

#### \_\_getitem_\_(item)

These fields are available:

* `TIMESTAMP` (or `Time`)
* `START_TIME` (or `_START_TIME`)
* `END_TIME` (or `_END_TIME`)
* `TIMEZONE` (or `_TIMEZONE`)
* `DBNAME` (or `_DBNAME`)
* `SYMBOL_NAME` (or `_SYMBOL_NAME`)
* `TICK_TYPE` (or `_TICK_TYPE`)
* `SYMBOL_TIME` (or `_SYMBOL_TIME`)
