# otp.remote

### remote(fun)

This decorator is needed in case function `fun`
is used in [`apply()`](https://docs.pip.distribution.sol.onetick.com/api/source/apply.html.md#onetick.py.Source.apply) method in a Remote OTP with Ray context.

We want to get source code of the function locally
because we will not be able to get source code on the remote server.

#### SEE ALSO
[Remote OTP with Ray](https://docs.pip.distribution.sol.onetick.com/static/installation/ray/ray_remote.html.md#ray-remote).
