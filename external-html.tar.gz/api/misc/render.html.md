# otp.utils.render_otq

### *class* render_otq(path, image_path=None, output_format=None, load_external_otqs=True, view=False, line_limit=(10, 60), parse_eval_from_params=False, render_debug_info=False, debug=False, graphviz_compat_mode=False, font_family=None, font_size=None)

Bases:

Render queries from .otq files.

* **Parameters:**
  * **path** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* [*list*](https://docs.python.org/3/library/stdtypes.html#list) *[*[*str*](https://docs.python.org/3/library/stdtypes.html#str) *]*) -- Path to .otq file or list of paths to multiple .otq files.
    Needed to render query could be specified with the next format: path_to_otq::query_name
  * **image_path** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *None*) -- Path for generated image. If omitted, image will be saved in a temp dir
  * **output_format** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *None*) -- Graphviz rendering format. Default: svg.
    If image_path contains one of next extensions, output_format will be set automatically: png, svg, dot.
  * **load_external_otqs** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If set to True (default) dependencies from external .otq files (not listed in `path` param)
    will be loaded automatically.
  * **view** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Defines should generated image be shown after render.
  * **line_limit** ([*tuple*](https://docs.python.org/3/library/stdtypes.html#tuple) *[*[*int*](https://docs.python.org/3/library/functions.html#int) *,* [*int*](https://docs.python.org/3/library/functions.html#int) *]* *,* *None*) -- Limit for maximum number of lines and length of some EP parameters strings.
    First param is limit of lines, second - limit of characters in each line.
    If set to None limit disabled.
    If one of tuple values set to zero the corresponding limit disabled.
  * **parse_eval_from_params** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Enable parsing and printing eval sub-queries from EP parameters.
  * **render_debug_info** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Render additional debug information.
  * **debug** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Allow to print stdout or stderr from Graphviz render.
  * **graphviz_compat_mode** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Change internal parameters of result graph for better compatibility with old Graphviz versions.
    Could produce larger and less readable graphs.
  * **font_family** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- 

    Font name

    Default: **Monospace**
  * **font_size** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* [*float*](https://docs.python.org/3/library/functions.html#float) *,* *optional*) -- Font size
* **Return type:**
  Path to rendered image

### Examples

Render single file:

```pycon
>>> otp.utils.render_otq("./test.otq")  
```

![image](static/testing/images/render_otq_1.png)

Render multiple files:

```pycon
>>> otp.utils.render_otq(["./first.otq", "./second.otq"])  
```

![image](static/testing/images/render_otq_2.png)

Render specific queries from multiple files:

```pycon
>>> otp.utils.render_otq(["./first.otq", "./second.otq::some_query"])  
```

Change font type to **Times New Roman** and text size to **10**:

```pycon
>>> otp.utils.render_otq("./test.otq", font_family="Times-Roman", font_size=10)  
```
