# otp.QueryParameters

### *class* QueryParameters(\*, symbol_date=None, concurrency=None, batch_size=None, running=None, query_properties=None)

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

OneTick queries have different properties.

They can be set separately for each query in the resulting .otq file.

Some of them have separate setters and can be specified as separate fields here,
others can be specified with `query_properties` dictionary.

Not all properties are specified here, some of them may be set in different places:

> * some options in [`otp.config`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config)
> * some parameters in [`otp.DataSource`](https://docs.pip.distribution.sol.onetick.com/api/sources/data_source.html.md#onetick.py.DataSource) and other source classes
> * some parameters in [`otp.run`](https://docs.pip.distribution.sol.onetick.com/api/run.html.md#onetick.py.run)
> * etc.

If the query properties are set in different places at the same time,
the value specified last will take precedence.

The default value for all fields here is None, which means that field is not set.

### Examples

Set the query property when creating source object:

```pycon
>>> t = otp.Tick(A=1, query_parameters=otp.QueryParameters(query_properties={'ALLOW_GRAPH_REUSE': 'TRUE'}))
>>> t['ALLOW_GRAPH_REUSE'] = otp.get_query_property('ALLOW_GRAPH_REUSE')
>>> otp.run(t)
        Time  A ALLOW_GRAPH_REUSE
0 2003-12-01  1              TRUE
```

The property can be overridden when running the query:

```pycon
>>> otp.run(t, query_properties={'ALLOW_GRAPH_REUSE': 'FALSE'})
        Time  A ALLOW_GRAPH_REUSE
0 2003-12-01  1             FALSE
```

* **Parameters:**
  * **symbol_date** ([*datetime*](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime) *|* *None*)
  * **concurrency** ([*int*](https://docs.python.org/3/library/functions.html#int) *|* *None*)
  * **batch_size** ([*int*](https://docs.python.org/3/library/functions.html#int) *|* *None*)
  * **running** ([*bool*](https://docs.python.org/3/library/functions.html#bool) *|* *None*)
  * **query_properties** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict) *|* *None*)
