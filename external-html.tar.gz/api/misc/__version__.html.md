# otp._\_version_\_

Get current `onetick.py` version:

```pycon
>>> otp.__version__  
'1.118.0'
```
