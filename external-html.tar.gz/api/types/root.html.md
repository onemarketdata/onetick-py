<a id="otp-types"></a>

# Types

## Table Of Contents

* [otp.byte](https://docs.pip.distribution.sol.onetick.com/api/types/byte.html.md)
* [otp.decimal](https://docs.pip.distribution.sol.onetick.com/api/types/decimal.html.md)
* [otp.inf](https://docs.pip.distribution.sol.onetick.com/api/types/inf.html.md)
* [otp.int](https://docs.pip.distribution.sol.onetick.com/api/types/int.html.md)
* [otp.long](https://docs.pip.distribution.sol.onetick.com/api/types/long.html.md)
* [otp.msectime](https://docs.pip.distribution.sol.onetick.com/api/types/msectime.html.md)
* [otp.nan](https://docs.pip.distribution.sol.onetick.com/api/types/nan.html.md)
* [otp.nsectime](https://docs.pip.distribution.sol.onetick.com/api/types/nsectime.html.md)
* [otp.short](https://docs.pip.distribution.sol.onetick.com/api/types/short.html.md)
* [otp.string](https://docs.pip.distribution.sol.onetick.com/api/types/string.html.md)
* [otp.uint](https://docs.pip.distribution.sol.onetick.com/api/types/uint.html.md)
* [otp.ulong](https://docs.pip.distribution.sol.onetick.com/api/types/ulong.html.md)
* [otp.varstring](https://docs.pip.distribution.sol.onetick.com/api/types/varstring.html.md)
