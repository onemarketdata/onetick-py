# otp.RemoteTS

### *class* RemoteTS(host, port=None, protocol=None, resource=None, cep=False)

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

Class representing remote tick-server.
Can be [`used`](session.md#onetick.py.Session.use)
in [`otp.Session`](session.md#onetick.py.Session) as well as the local databases.

* **Parameters:**
  * **host** (str, [`LoadBalancing`](load_balancing.md#onetick.py.servers.LoadBalancing), [`FaultTolerance`](fault_tolerance.md#onetick.py.servers.FaultTolerance)) -- 

    In case of string: string with this format: `[proto://]hostname:port[/resource]`.
    Parameters in square brackets are optional.

    Otherwise, configuration can be set with [`LoadBalancing`](load_balancing.md#onetick.py.servers.LoadBalancing)
    and/or [`FaultTolerance`](fault_tolerance.md#onetick.py.servers.FaultTolerance) objects.
  * **port** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* [*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- The port number of the remote tick-server.
    If not specified here, can be specified in the `host` parameter.
  * **protocol** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- The protocol to connect with.
    If not specified here, can be specified in the `host` parameter.
  * **resource** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- The resource of the host.
    If not specified here, can be specified in the `host` parameter.
  * **cep** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- Specifies if the remote server is the CEP-mode tick-server.

### Examples

Specify host name and port together in first parameter:

```pycon
>>> session.use(otp.RemoteTS('server.onetick.com:50015'))  
```

Additionally specify web-socket protocol and resource of the remote server:

```pycon
>>> session.use(otp.RemoteTS('wss://data.onetick.com:443/omdwebapi/websocket'))  
```

Combination of [`LoadBalancing`](load_balancing.md#onetick.py.servers.LoadBalancing)
and [`FaultTolerance`](fault_tolerance.md#onetick.py.servers.FaultTolerance) can be used for host parameter:

```pycon
>>> otp.RemoteTS(otp.FaultTolerance(otp.LoadBalancing('host1:4001', 'host2:4002'),
...                                 otp.LoadBalancing('host3:4003', 'host3:4004')) 
```
