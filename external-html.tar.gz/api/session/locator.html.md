# otp.Locator

### *class* Locator(path=None, clean_up=utils.default, copy=True, empty=False, session_ref=None)

Class representing OneTick database locator.
Locator is the file that describes database name, location and other options.

This object can be used when creating [`otp.Config`](https://docs.pip.distribution.sol.onetick.com/api/session/config.html.md#onetick.py.session.Config) object.

* **Parameters:**
  * **path** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- 

    A path to custom locator file.

    Default is None, which means to generate locator file automatically.
  * **clean_up** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- 

    If True, then temporary locator will be removed when Locator object will be destroyed. It is
    helpful for debug purpose.

    By default,
    [`otp.config.clean_up_tmp_files`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.clean_up_tmp_files) is used.
  * **copy** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If True, then the passed custom locator by the `path` parameter will be copied firstly before
    usage. It might be used when you want to work with a custom locator, but don't want to change
    the original file; in that case a custom locator will be copied into a temporary locator and
    every request for modification will be executed for that temporary locator. Default is True.
  * **empty** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- 

    If True, then a temporary locator will have no databases.

    Default is False, which means it will include some default databases like COMMON
    and [`otp.config.default_db`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.default_db).

### Examples

Locator object can be created with existing path:

```pycon
>>> locator = otp.Locator('/path/to/the/locator')  
```

Or it can be created automatically with some default values:

```pycon
>>> locator = otp.Locator()  
>>> locator.path             
'/tmp/test_username/run_20260722_145505_4775/observant-jackrabbit.locator'
```

#### SEE ALSO
[`otp.Session`](https://docs.pip.distribution.sol.onetick.com/api/session/session.html.md#onetick.py.Session)
[`otp.Config`](https://docs.pip.distribution.sol.onetick.com/api/session/config.html.md#onetick.py.session.Config)
[`otp.ACL`](https://docs.pip.distribution.sol.onetick.com/api/session/acl.html.md#onetick.py.session.ACL)
