# otp.LoadBalancing

### *class* LoadBalancing(\*sockets)

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

Class representing configuration of client-side load-balancing between multiple tick servers.
Each client query selects the target tick server from the provided list according to the load-balancing policy.
Currently only SERVER_LOAD_WEIGHTED policy is available -  tick servers are chosen at random using a weighted
probability distribution, using inverted CPU usage for weights.
LoadBalancing class is used only with [`RemoteTS`](remote_ts.md#onetick.py.servers.RemoteTS) and
[`FaultTolerance`](fault_tolerance.md#onetick.py.servers.FaultTolerance).

* **Parameters:**
  **sockets** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Sockets used in load-balancing configuration.

### Examples

```pycon
>>> LoadBalancing('host1:4001', 'host2:4002', 'host3:4003') 
```
