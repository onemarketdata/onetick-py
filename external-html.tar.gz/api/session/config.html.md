# otp.Config

### *class* Config(config=None, locator=None, acl=None, otq_path=None, csv_path=None, clean_up=utils.default, copy=True, session_ref=None, license=None, variables=None)

The object to create and modify OneTick main configuration file.

This object can be used when creating [`otp.Session`](https://docs.pip.distribution.sol.onetick.com/api/session/session.html.md#onetick.py.Session) object.

* **Parameters:**
  * **config** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *or* [*Config*](#onetick.py.session.Config)) -- 

    Allows to specify a custom config.

    Default is None, which means to generate configuration file automatically.
    It will include some default OneTick variables set.
  * **locator** ([`otp.Locator`](https://docs.pip.distribution.sol.onetick.com/api/session/locator.html.md#onetick.py.session.Locator)                  or dict[str, [`otp.Locator`](https://docs.pip.distribution.sol.onetick.com/api/session/locator.html.md#onetick.py.session.Locator)]                  or [`otp.RemoteTS`](https://docs.pip.distribution.sol.onetick.com/api/session/remote_ts.html.md#onetick.py.servers.RemoteTS)) -- 

    Allows to specify a custom locator file.

    If **dict** passed, adds locators passed as values to corresponding contexts from keys.
    For default context pass locator by **DEFAULT** dictionary key.

    If [`otp.RemoteTS`](https://docs.pip.distribution.sol.onetick.com/api/session/remote_ts.html.md#onetick.py.servers.RemoteTS)
    then locator file pointing to the remote server will be created.

    Default is None, which means to generate locator file automatically.
    It will include some default databases like COMMON
    and [`otp.config.default_db`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.default_db).
  * **acl** ([`otp.ACL`](https://docs.pip.distribution.sol.onetick.com/api/session/acl.html.md#onetick.py.session.ACL)) -- 

    Allows to specify a custom ACL file.

    Default is None, which means to generate ACL file automatically.
    It will include current user with permissions to execute EPs and read/write databases.
  * **otq_path** ([*list*](https://docs.python.org/3/library/stdtypes.html#list) *of* *paths to lookup queries*) -- OTQ_PATH parameter in the OneTick config file. Default is None, that is equal to the empty list.
  * **csv_path** ([*list*](https://docs.python.org/3/library/stdtypes.html#list) *of* *paths to lookup csv files*) -- CSV_PATH parameter in the OneTick config file. Default is None, that is equal to the empty list.
  * **clean_up** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- 

    If True, then temporary config file will be removed when the Config instance will be destroyed.
    It is helpful for debug purpose.

    By default,
    [`otp.config.clean_up_tmp_files`](https://docs.pip.distribution.sol.onetick.com/api/config.html.md#onetick.py.configuration.Config.clean_up_tmp_files) is used.
  * **copy** ([*bool*](https://docs.python.org/3/library/functions.html#bool)) -- If True, then the passed custom config file will be copied firstly before any usage with it.
    It might be used when you want to work with a custom config file, but don't want to change to
    change the original file; in that case a custom config will be copied into a temporary config
    file and every request for modification will be executed for that temporary config. Default
    is True.
  * **license** (*instance from the onetick.py.license module*) -- License to use. If it is not set, then onetick.py.license.Default is used.
  * **variables** ([*dict*](https://docs.python.org/3/library/stdtypes.html#dict)) -- Other values to pass to config.

### Examples

Configuration object can be created with existing path:

```pycon
>>> config = otp.Config('/path/to/the/config')  
```

Or it can be created automatically with some default values:

```pycon
>>> config = otp.Config()  
>>> config.path            
'/tmp/test_username/run_20260722_145505_4775/carrot-unicorn.cfg'
```

Custom locator and ACL files can be specified:

```pycon
>>> config = otp.Config(           
...     locator=otp.Locator(...),  
...     acl=otp.ACL(...)           
... )                              
```

[`otp.RemoteTS`](https://docs.pip.distribution.sol.onetick.com/api/session/remote_ts.html.md#onetick.py.servers.RemoteTS) object can also be specified as `locator`:

```pycon
>>> config = otp.Config(                                       
...     locator=otp.RemoteTS('path.to.the.server.com:50015'),  
... )                                                          
```

#### SEE ALSO
[`otp.Session`](https://docs.pip.distribution.sol.onetick.com/api/session/session.html.md#onetick.py.Session)
[`otp.Locator`](https://docs.pip.distribution.sol.onetick.com/api/session/locator.html.md#onetick.py.session.Locator)
[`otp.ACL`](https://docs.pip.distribution.sol.onetick.com/api/session/acl.html.md#onetick.py.session.ACL)
