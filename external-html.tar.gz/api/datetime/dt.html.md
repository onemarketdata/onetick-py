# otp.dt (otp.datetime)

### *class* datetime(first_arg, month=None, day=None, hour=None, minute=None, second=None, microsecond=None, nanosecond=None, \*, tzinfo=None, tz=None)

Bases: `AbstractTime`

Class [`otp.datetime`](#onetick.py.datetime) is used for representing date with time in onetick-py.
It can be used both when specifying start and end time for queries and
in column operations with [`onetick.py.Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source).
[Datetime offset objects](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) (e.g. otp.Nano, otp.Day)
can be added to or subtracted from otp.datetime object.

* **Parameters:**
  * **first_arg** (int, str, [`otp.datetime`](#onetick.py.datetime), [`otp.date`](https://docs.pip.distribution.sol.onetick.com/api/datetime/date.html.md#onetick.py.date)                [pandas.Timestamp](https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html), [`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime)) -- If month, day and other parts of date are specified,
    first argument will be considered as year.
    Otherwise, first argument will be converted to [`otp.datetime`](#onetick.py.datetime).
  * **month** ([*int*](https://docs.python.org/3/library/functions.html#int)) -- Number between 1 and 12.
  * **day** ([*int*](https://docs.python.org/3/library/functions.html#int)) -- Number between 1 and 31.
  * **hour** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=0*) -- Number between 0 and 23.
  * **minute** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=0*) -- Number between 0 and 59.
  * **second** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=0*) -- Number between 0 and 59.
  * **microsecond** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=0*) -- Number between 0 and 999999.
  * **nanosecond** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *default=0*) -- Number between 0 and 999.
  * **tzinfo** ([`datetime.tzinfo`](#onetick.py.datetime.tzinfo)) -- Timezone object.
  * **tz** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- Timezone name.

#### NOTE
Class [`otp.datetime`](#onetick.py.datetime) share many methods
that classes [pandas.Timestamp](https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html) and [`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime) have,
but these objects are not fully interchangeable.
Class [`otp.datetime`](#onetick.py.datetime) should work in all onetick-py methods and classes,
other classes should work too if documented,
and may even work when not documented, but the users should not count on it.

### Examples

Initialization by [`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime) class from standard library:

```pycon
>>> otp.datetime(datetime.datetime(2019, 1, 1, 1))
2019-01-01 01:00:00
```

Initialization by [pandas.Timestamp](https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html) class:

```pycon
>>> otp.datetime(pd.Timestamp(2019, 1, 1, 1))
2019-01-01 01:00:00
```

Initialization by int timestamp:

```pycon
>>> otp.datetime(1234567890)
1970-01-01 00:00:01.234567890
```

Initialization by params with nanoseconds:

```pycon
>>> otp.datetime(2019, 1, 1, 1, 2, 3, 4, 5)
2019-01-01 01:02:03.000004005
```

Initialization by string:

```pycon
>>> otp.datetime('2019/01/01 1:02')
2019-01-01 01:02:00
```

otp.dt is the alias for otp.datetime:

```pycon
>>> otp.dt(2019, 1, 1)
2019-01-01 00:00:00
```

#### SEE ALSO
[Datetime offset objects](https://docs.pip.distribution.sol.onetick.com/static/concepts/start_end.html.md#datetime-guide).

#### *property* start

#### *property* end

#### replace(\*\*kwargs)

Replace parts of otp.datetime object.

* **Parameters:**
  * **year** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **month** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **day** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **hour** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **minute** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **second** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **microsecond** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **nanosecond** ([*int*](https://docs.python.org/3/library/functions.html#int) *,* *optional*)
  * **tzinfo** (*tz-convertible* *,* *optional*)
* **Returns:**
  **result** -- Timestamp with fields replaced.
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime)

### Examples

```pycon
>>> ts = otp.datetime(2022, 2, 24, 3, 15, 54, 999, 1)
>>> ts
2022-02-24 03:15:54.000999001
>>> ts.replace(year=2000, month=2, day=2, hour=2, minute=2, second=2, microsecond=2, nanosecond=2)
2000-02-02 02:02:02.000002002
```

#### *property* tz

#### *property* tzinfo

#### *property* hour

#### *property* minute

#### *property* second

#### *property* microsecond

#### *property* nanosecond

#### *static* now(tz=None)

Will return [`otp.datetime`](#onetick.py.datetime) object
with timestamp at the moment of calling this function.
Not to be confused with function [`otp.now`](https://docs.pip.distribution.sol.onetick.com/api/datetime/now.html.md#onetick.py.now) which can only add column
with current timestamp to the [`otp.Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) when running the query.

* **Parameters:**
  **tz** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *or* *timezone object* *,* *default None*) -- Timezone to localize to.

#### weekday()

Return the day of the week as an integer, where Monday is 0 and Sunday is 6.

* **Returns:**
  Day of the week (0=Monday, 1=Tuesday, ..., 6=Sunday).
* **Return type:**
  [int](https://docs.python.org/3/library/functions.html#int)

### Examples

```pycon
>>> otp.datetime(2026, 1, 23).weekday()  # Friday
4
>>> otp.datetime(2026, 1, 25).weekday()  # Sunday
6
>>> otp.datetime(2026, 1, 19).weekday()  # Monday
0
```

#### *classmethod* strptime(date_string, format, \*, tz=None, tzinfo=None)

Parse a string to datetime according to a format.

* **Parameters:**
  * **date_string** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- The string to parse.
  * **format** ([*str*](https://docs.python.org/3/library/stdtypes.html#str)) -- The format string for parsing.
  * **tz** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *,* *optional*) -- Timezone name.
  * **tzinfo** ([`datetime.tzinfo`](#onetick.py.datetime.tzinfo), optional) -- Timezone object.
* **Returns:**
  The parsed datetime object.
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime)

### Examples

```pycon
>>> otp.datetime.strptime('2026-01-23 14:30:00', '%Y-%m-%d %H:%M:%S')
2026-01-23 14:30:00
>>> otp.datetime.strptime('2026-01-23 14:30:00', '%Y-%m-%d %H:%M:%S', tz='GMT')
2026-01-23 14:30:00+00:00
```

* **Raises:**
  [**ValueError**](https://docs.python.org/3/library/exceptions.html#ValueError) -- If the string cannot be parsed according to the format,
      or if both `tz` and `tzinfo` are specified.

#### \_\_add_\_(other)

Add [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) to otp.datetime.

* **Parameters:**
  **other** ([datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1), [`otp.datetime`](#onetick.py.datetime)) -- object to add
* **Returns:**
  **result** -- return [`otp.datetime`](#onetick.py.datetime)
  if otp.Nano or another [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) object was passed as an argument,
  or [pandas.Timedelta](https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html) object if [`otp.datetime`](#onetick.py.datetime)
  was passed as an argument.
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime), [pandas.Timedelta](https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html)

### Examples

```pycon
>>> otp.datetime(2022, 2, 24) + otp.Nano(1)
2022-02-24 00:00:00.000000001
```

#### \_\_sub_\_(other)

Subtract [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1) from otp.datetime.

* **Parameters:**
  **other** ([datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1), [`otp.datetime`](#onetick.py.datetime)) -- object to subtract
* **Returns:**
  **result** -- return datetime if otp.Nano or another [datetime offset](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/root.html.md#id1)
  object was passed as an argument,
  or [pandas.Timedelta](https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html) object if [`otp.datetime`](#onetick.py.datetime)
  was passed as an argument.
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime), [pandas.Timedelta](https://pandas.pydata.org/docs/reference/api/pandas.Timedelta.html)

### Examples

```pycon
>>> otp.datetime(2022, 2, 24) - otp.Nano(1)
2022-02-23 23:59:59.999999999
```

#### tz_localize(tz)

Localize a timezone-naive datetime object to the specified timezone

* **Parameters:**
  **tz** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *or* *tzinfo*) -- timezone to localize datetime object into
* **Returns:**
  **result** -- localized datetime object
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime)

### Examples

```pycon
>>> d = otp.datetime(2021, 6, 3)
>>> d.tz_localize("EST5EDT")
2021-06-03 00:00:00-04:00
```

#### tz_convert(tz)

Convert a timezone-aware datetime object to a different timezone

* **Parameters:**
  **tz** ([*str*](https://docs.python.org/3/library/stdtypes.html#str) *or* *tzinfo*) -- timezone to convert datetime object into
* **Returns:**
  **result** -- converted datetime object
* **Return type:**
  [`otp.datetime`](#onetick.py.datetime)

### Examples

```pycon
>>> d = otp.datetime(2021, 6, 3, tz="EST5EDT")
>>> d.tz_convert("Europe/Moscow")
2021-06-03 07:00:00+03:00
```

#### to_operation(timezone=None)

Convert [`otp.datetime`](#onetick.py.datetime) object to
[`otp.Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

* **Parameters:**
  **timezone** ([*Operation*](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)) -- Can be used to specify timezone as an Operation.

### Examples

```pycon
>>> t = otp.Ticks(TZ=['EST5EDT', 'GMT'])
>>> t['DT'] = otp.dt(2022, 1, 1).to_operation(timezone=t['TZ'])
>>> otp.run(t, timezone='GMT')[['TZ', 'DT']]
        TZ                  DT
0  EST5EDT 2022-01-01 05:00:00
1      GMT 2022-01-01 00:00:00
```
