# Datetime offsets

<a id="id1"></a>

`onetick.py` objects representing datetime offset.

Can be added to or subtracted from:

* [`otp.datetime`](../dt.md#onetick.py.datetime) objects
* [`Source`](../../source/root.md#onetick.py.Source) columns of datetime type
