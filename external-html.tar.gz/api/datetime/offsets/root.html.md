# Datetime offsets

<a id="id1"></a>

`onetick.py` objects representing datetime offset.

Can be added to or subtracted from:

* [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime) objects
* [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) columns of datetime type

## Table Of Contents

* [otp.Nano](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/nano.html.md)
* [otp.Milli](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/milli.html.md)
* [otp.Second](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/second.html.md)
* [otp.Minute](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/minute.html.md)
* [otp.Hour](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/hour.html.md)
* [otp.Day](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/day.html.md)
* [otp.Week](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/week.html.md)
* [otp.Month](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/month.html.md)
* [otp.Quarter](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/quarter.html.md)
* [otp.Year](https://docs.pip.distribution.sol.onetick.com/api/datetime/offsets/year.html.md)
