# otp.Minute

### Minute(n)

Object representing minute's datetime offset.

Can be added to or subtracted from:

* [`otp.datetime`](../dt.md#onetick.py.datetime) objects
* [`Source`](../../source/root.md#onetick.py.Source) columns of datetime type

* **Parameters:**
  **n** (int, [`Column`](../../operation/root.md#onetick.py.Column), [`Operation`](../../operation/root.md#onetick.py.Operation)) -- Offset integer value or column of [`Source`](../../source/root.md#onetick.py.Source).
  The only [`Operation`](../../operation/root.md#onetick.py.Operation) supported is
  subtracting one datetime column from another. See example below.

### Examples

Add to or subtract from [`otp.datetime`](../dt.md#onetick.py.datetime) object:

```pycon
>>> otp.datetime(2012, 12, 12, 12) + otp.Minute(1)
2012-12-12 12:01:00
>>> otp.datetime(2012, 12, 12, 12) - otp.Minute(1)
2012-12-12 11:59:00
```

Use offset in columns:

```pycon
>>> t = otp.Tick(A=1)
>>> t['T'] = otp.datetime(2012, 12, 12, 12)
>>> t['T'] += otp.Minute(t['A'])
>>> otp.run(t)
        Time                   T  A
0 2003-12-01 2012-12-12 12:01:00  1
```

Use it to calculate difference between two dates:

```pycon
>>> t = otp.Tick(A=otp.dt(2022, 1, 1), B=otp.dt(2022, 1, 1, 1))
>>> t['DIFF'] = otp.Minute(t['B'] - t['A'])
>>> otp.run(t)
        Time           A                    B  DIFF
0 2003-12-01  2022-01-01  2022-01-01 01:00:00    60
```
