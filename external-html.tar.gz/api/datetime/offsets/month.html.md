# otp.Month

### Month(n)

Object representing month's datetime offset.

Can be added to or subtracted from:

* [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime) objects
* [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) columns of datetime type

* **Parameters:**
  **n** (int, [`Column`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column), [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)) -- Offset integer value or column of [`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source).
  The only [`Operation`](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation) supported is
  subtracting one datetime column from another. See example below.

### Examples

Add to or subtract from [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime) object:

```pycon
>>> otp.datetime(2012, 12, 12, 12) + otp.Month(1)
2013-01-12 12:00:00
>>> otp.datetime(2012, 12, 12, 12) - otp.Month(1)
2012-11-12 12:00:00
```

Use offset in columns:

```pycon
>>> t = otp.Tick(A=1)
>>> t['T'] = otp.datetime(2012, 12, 12, 12)
>>> t['T'] += otp.Month(t['A'])
>>> otp.run(t)
        Time                   T  A
0 2003-12-01 2013-01-12 12:00:00  1
```

Use it to calculate difference between two dates:

```pycon
>>> t = otp.Tick(A=otp.dt(2022, 1, 1), B=otp.dt(2023, 1, 1))
>>> t['DIFF'] = otp.Month(t['B'] - t['A'])
>>> otp.run(t)
        Time           A           B  DIFF
0 2003-12-01  2022-01-01  2023-01-01    12
```
