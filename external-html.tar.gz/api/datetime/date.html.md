# otp.date

### *class* date(first_arg, month=None, day=None)

Bases: [`datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime)

Class `date` is used for representing date in onetick-py.
It can be used both when specifying start and end time for queries and
in column operations with [`onetick.py.Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source).

* **Parameters:**
  * **first_arg** (int, str, [`otp.datetime`](https://docs.pip.distribution.sol.onetick.com/api/datetime/dt.html.md#onetick.py.datetime), [`otp.date`](#onetick.py.date)                [pandas.Timestamp](https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html), [`datetime.datetime`](https://docs.python.org/3/library/datetime.html#datetime.datetime), [`datetime.date`](https://docs.python.org/3/library/datetime.html#datetime.date)) -- If month and day arguments are specified, first argument will be considered as year.
    Otherwise, first argument will be converted to otp.date.
  * **month** ([*int*](https://docs.python.org/3/library/functions.html#int)) -- Number between 1 and 12.
  * **day** ([*int*](https://docs.python.org/3/library/functions.html#int)) -- Number between 1 and 31.

#### NOTE
Class [`otp.date`](#onetick.py.date) share many methods
that classes [pandas.Timestamp](https://pandas.pydata.org/docs/reference/api/pandas.Timestamp.html) and [`datetime.date`](https://docs.python.org/3/library/datetime.html#datetime.date) have,
but these objects are not fully interchangeable.
Class [`otp.date`](#onetick.py.date) should work in all onetick-py methods and classes,
other classes should work too if documented,
and may even work when not documented, but the users should not count on it.

### Examples

[Datetime guide](https://docs.pip.distribution.sol.onetick.com/static/concepts/start_end.html.md#datetime-guide).
