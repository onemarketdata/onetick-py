# Datetime accessor

#### *property* Operation.dt

Property that provides access to methods specific to datetime types.

#### SEE ALSO
[`otp.nsectime`](https://docs.pip.distribution.sol.onetick.com/api/types/nsectime.html.md#onetick.py.nsectime)
[`otp.msectime`](https://docs.pip.distribution.sol.onetick.com/api/types/msectime.html.md#onetick.py.msectime)

## Table Of Contents

* [otp.Operation.dt.date](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/date.html.md)
* [otp.Operation.dt.date_trunc](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/date_trunc.html.md)
* [otp.Operation.dt.day_name](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/day_name.html.md)
* [otp.Operation.dt.day_of_month](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/day_of_month.html.md)
* [otp.Operation.dt.day_of_week](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/day_of_week.html.md)
* [otp.Operation.dt.day_of_year](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/day_of_year.html.md)
* [otp.Operation.dt.hour](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/hour.html.md)
* [otp.Operation.dt.minute](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/minute.html.md)
* [otp.Operation.dt.month](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/month.html.md)
* [otp.Operation.dt.month_name](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/month_name.html.md)
* [otp.Operation.dt.quarter](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/quarter.html.md)
* [otp.Operation.dt.second](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/second.html.md)
* [otp.Operation.dt.strftime](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/strftime.html.md)
* [otp.Operation.dt.week](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/week.html.md)
* [otp.Operation.dt.year](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/year.html.md)
