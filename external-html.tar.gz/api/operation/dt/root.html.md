# Datetime accessor

#### *property* Operation.dt

Property that provides access to methods specific to datetime types.

#### SEE ALSO
[`otp.nsectime`](../../types/nsectime.md#onetick.py.nsectime)
[`otp.msectime`](../../types/msectime.md#onetick.py.msectime)
