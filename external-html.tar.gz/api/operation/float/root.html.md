# Float accessor

#### *property* Operation.float

Property that provides access to
methods specific to float type.

## Table Of Contents

* [otp.Operation.float.cmp](https://docs.pip.distribution.sol.onetick.com/api/operation/float/cmp.html.md)
* [otp.Operation.float.eq](https://docs.pip.distribution.sol.onetick.com/api/operation/float/eq.html.md)
* [otp.Operation.float.str](https://docs.pip.distribution.sol.onetick.com/api/operation/float/str.html.md)
