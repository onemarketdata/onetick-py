# otp.Operation

### *class* Operation

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

[`Source`](../source/root.md#onetick.py.Source) column operation container.

This is the object you get when applying most operations on [`Column`](#onetick.py.Column)
or on other operations.
Eventually you can add a new column using the operation you got or pass it as a parameter
to some functions.

### Examples

```pycon
>>> t = otp.Tick(A=1)
>>> t['A']
Column(A, <class 'int'>)
>>> t['A'] / 2
Operation((A) / (2))
>>> t['B'] = t['A'] / 2
>>> t['B']
Column(B, <class 'float'>)
```

### *class* Column

Bases: [`Operation`](#onetick.py.Operation)

[`Source`](../source/root.md#onetick.py.Source) column container.

This is the object you get when using [`__getitem__()`](../source/__getitem__.md#onetick.py.Source.__getitem__).
You can use this object everywhere where [`Operation`](#onetick.py.Operation) object can be used.

### Examples

```pycon
>>> t = otp.Tick(A=1)
>>> t['A']
Column(A, <class 'int'>)
```
