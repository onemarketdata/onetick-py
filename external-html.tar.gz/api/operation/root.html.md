# otp.Operation

### *class* Operation

Bases: [`object`](https://docs.python.org/3/library/functions.html#object)

[`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) column operation container.

This is the object you get when applying most operations on [`Column`](#onetick.py.Column)
or on other operations.
Eventually you can add a new column using the operation you got or pass it as a parameter
to some functions.

### Examples

```pycon
>>> t = otp.Tick(A=1)
>>> t['A']
Column(A, <class 'int'>)
>>> t['A'] / 2
Operation((A) / (2))
>>> t['B'] = t['A'] / 2
>>> t['B']
Column(B, <class 'float'>)
```

### *class* Column

Bases: [`Operation`](#onetick.py.Operation)

[`Source`](https://docs.pip.distribution.sol.onetick.com/api/source/root.html.md#onetick.py.Source) column container.

This is the object you get when using [`__getitem__()`](https://docs.pip.distribution.sol.onetick.com/api/source/__getitem__.html.md#onetick.py.Source.__getitem__).
You can use this object everywhere where [`Operation`](#onetick.py.Operation) object can be used.

### Examples

```pycon
>>> t = otp.Tick(A=1)
>>> t['A']
Column(A, <class 'int'>)
```

## Table Of Contents

* [otp.Column._\_getitem_\_](https://docs.pip.distribution.sol.onetick.com/api/operation/__getitem__.html.md)
* [otp.Operation.apply](https://docs.pip.distribution.sol.onetick.com/api/operation/apply.html.md)
* [otp.Operaion.astype](https://docs.pip.distribution.sol.onetick.com/api/operation/astype.html.md)
* [otp.Column.cumsum](https://docs.pip.distribution.sol.onetick.com/api/operation/cumsum.html.md)
* [otp.Operation.dtype](https://docs.pip.distribution.sol.onetick.com/api/operation/dtype.html.md)
* [otp.Operation.expr](https://docs.pip.distribution.sol.onetick.com/api/operation/expr.html.md)
* [otp.Operation.fillna](https://docs.pip.distribution.sol.onetick.com/api/operation/fillna.html.md)
* [otp.Operation.isin](https://docs.pip.distribution.sol.onetick.com/api/operation/isin.html.md)
* [otp.Operation.map](https://docs.pip.distribution.sol.onetick.com/api/operation/map.html.md)
* [otp.Operation.round](https://docs.pip.distribution.sol.onetick.com/api/operation/round.html.md)
* [Math operations](https://docs.pip.distribution.sol.onetick.com/api/operation/math/root.html.md)
* [Datetime accessor](https://docs.pip.distribution.sol.onetick.com/api/operation/dt/root.html.md)
* [Float accessor](https://docs.pip.distribution.sol.onetick.com/api/operation/float/root.html.md)
* [Decimal accessor](https://docs.pip.distribution.sol.onetick.com/api/operation/decimal/root.html.md)
* [String accessor](https://docs.pip.distribution.sol.onetick.com/api/operation/str/root.html.md)
