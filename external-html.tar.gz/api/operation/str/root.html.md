# String accessor

#### *property* Operation.str

Property that provides access to methods specific to string types.

#### SEE ALSO
[`otp.string`](https://docs.pip.distribution.sol.onetick.com/api/types/string.html.md#onetick.py.string)

## Table Of Contents

* [otp.Operation.str.concat](https://docs.pip.distribution.sol.onetick.com/api/operation/str/concat.html.md)
* [otp.Operation.str.contains](https://docs.pip.distribution.sol.onetick.com/api/operation/str/contains.html.md)
* [otp.Operation.str.endswith](https://docs.pip.distribution.sol.onetick.com/api/operation/str/endswith.html.md)
* [otp.Operation.str.extract](https://docs.pip.distribution.sol.onetick.com/api/operation/str/extract.html.md)
* [otp.Operation.str.find](https://docs.pip.distribution.sol.onetick.com/api/operation/str/find.html.md)
* [otp.Operation.str.first](https://docs.pip.distribution.sol.onetick.com/api/operation/str/first.html.md)
* [otp.Operation.str.get](https://docs.pip.distribution.sol.onetick.com/api/operation/str/get.html.md)
* [otp.Operation.str.ilike](https://docs.pip.distribution.sol.onetick.com/api/operation/str/ilike.html.md)
* [otp.Operation.str.insert](https://docs.pip.distribution.sol.onetick.com/api/operation/str/insert.html.md)
* [otp.Operation.str.last](https://docs.pip.distribution.sol.onetick.com/api/operation/str/last.html.md)
* [otp.Operation.str.len](https://docs.pip.distribution.sol.onetick.com/api/operation/str/len.html.md)
* [otp.Operation.str.like](https://docs.pip.distribution.sol.onetick.com/api/operation/str/like.html.md)
* [otp.Operation.str.lower](https://docs.pip.distribution.sol.onetick.com/api/operation/str/lower.html.md)
* [otp.Operation.str.ltrim](https://docs.pip.distribution.sol.onetick.com/api/operation/str/ltrim.html.md)
* [otp.Operation.str.match](https://docs.pip.distribution.sol.onetick.com/api/operation/str/match.html.md)
* [otp.Operation.str.regex_replace](https://docs.pip.distribution.sol.onetick.com/api/operation/str/regex_replace.html.md)
* [otp.Operation.str.repeat](https://docs.pip.distribution.sol.onetick.com/api/operation/str/repeat.html.md)
* [otp.Operation.str.replace](https://docs.pip.distribution.sol.onetick.com/api/operation/str/replace.html.md)
* [otp.Operation.str.rtrim](https://docs.pip.distribution.sol.onetick.com/api/operation/str/rtrim.html.md)
* [otp.Operation.str.slice](https://docs.pip.distribution.sol.onetick.com/api/operation/str/slice.html.md)
* [otp.Operation.str.startswith](https://docs.pip.distribution.sol.onetick.com/api/operation/str/startswith.html.md)
* [otp.Operation.str.strptime](https://docs.pip.distribution.sol.onetick.com/api/operation/str/strptime.html.md)
* [otp.Operation.str.substr](https://docs.pip.distribution.sol.onetick.com/api/operation/str/substr.html.md)
* [otp.Operation.str.to_datetime](https://docs.pip.distribution.sol.onetick.com/api/operation/str/to_datetime.html.md)
* [otp.Operation.str.token](https://docs.pip.distribution.sol.onetick.com/api/operation/str/token.html.md)
* [otp.Operation.str.trim](https://docs.pip.distribution.sol.onetick.com/api/operation/str/trim.html.md)
* [otp.Operation.str.upper](https://docs.pip.distribution.sol.onetick.com/api/operation/str/upper.html.md)
