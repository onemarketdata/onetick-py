# otp.Operation.str.rtrim

### rtrim()

Removes the trailing white spaces from a string.

* **Returns:**
  Trimmed string
* **Return type:**
  [Operation](../root.md#onetick.py.Operation)

#### SEE ALSO
[`ltrim()`](ltrim.md#onetick.py.core.column_operations.accessors.str_accessor.ltrim), [`trim()`](trim.md#onetick.py.core.column_operations.accessors.str_accessor.trim)
