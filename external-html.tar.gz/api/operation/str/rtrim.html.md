# otp.Operation.str.rtrim

### rtrim()

Removes the trailing white spaces from a string.

* **Returns:**
  Trimmed string
* **Return type:**
  [Operation](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

#### SEE ALSO
[`ltrim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/ltrim.html.md#onetick.py.core.column_operations.accessors.str_accessor.ltrim), [`trim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/trim.html.md#onetick.py.core.column_operations.accessors.str_accessor.trim)
