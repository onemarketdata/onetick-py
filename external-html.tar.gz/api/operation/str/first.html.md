# otp.Operation.str.first

### first(count=1)

Returns first `count` symbols.

* **Parameters:**
  **count** ([*int*](https://docs.python.org/3/library/functions.html#int) *or* [*Column*](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Column) *or* [*Operation*](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)) -- Number of first symbols to return. Default: 1

### Examples

```pycon
>>> data = otp.Ticks(X=['abc', 'bac', 'cba'], Y=[3, 1, 10])
>>> data['FIRST'] = data['X'].str.first()
>>> data['FIRST_Y'] = data['X'].str.first(data['Y'])
>>> otp.run(data)
                     Time    X   Y FIRST FIRST_Y
0 2003-12-01 00:00:00.000  abc   3     a     abc
1 2003-12-01 00:00:00.001  bac   1     b       b
2 2003-12-01 00:00:00.002  cba  10     c     cba
```
