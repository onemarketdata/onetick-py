# otp.Operation.str.trim

### trim()

Removes white spaces from both sides of the string.

* **Returns:**
  Trimmed string
* **Return type:**
  [Operation](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

### Examples

```pycon
>>> data = otp.Ticks(X=['  Hello', 'World  '])
>>> data['X'] = data['X'].str.trim()
>>> otp.run(data)
                     Time      X
0 2003-12-01 00:00:00.000  Hello
1 2003-12-01 00:00:00.001  World
```

#### SEE ALSO
[`ltrim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/ltrim.html.md#onetick.py.core.column_operations.accessors.str_accessor.ltrim), [`rtrim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/rtrim.html.md#onetick.py.core.column_operations.accessors.str_accessor.rtrim)
