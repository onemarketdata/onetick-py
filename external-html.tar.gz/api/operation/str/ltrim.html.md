# otp.Operation.str.ltrim

### ltrim()

Removes the leading white spaces from a string.

* **Returns:**
  Trimmed string
* **Return type:**
  [Operation](../root.md#onetick.py.Operation)

#### SEE ALSO
[`trim()`](trim.md#onetick.py.core.column_operations.accessors.str_accessor.trim), [`rtrim()`](rtrim.md#onetick.py.core.column_operations.accessors.str_accessor.rtrim)
