# otp.Operation.str.ltrim

### ltrim()

Removes the leading white spaces from a string.

* **Returns:**
  Trimmed string
* **Return type:**
  [Operation](https://docs.pip.distribution.sol.onetick.com/api/operation/root.html.md#onetick.py.Operation)

#### SEE ALSO
[`trim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/trim.html.md#onetick.py.core.column_operations.accessors.str_accessor.trim), [`rtrim()`](https://docs.pip.distribution.sol.onetick.com/api/operation/str/rtrim.html.md#onetick.py.core.column_operations.accessors.str_accessor.rtrim)
