# Decimal accessor

#### *property* Operation.decimal

Property that provides access to methods specific to decimal type.

#### SEE ALSO
[`otp.decimal`](https://docs.pip.distribution.sol.onetick.com/api/types/decimal.html.md#onetick.py.decimal)

## Table Of Contents

* [otp.Operation.decimal.cmp](https://docs.pip.distribution.sol.onetick.com/api/operation/decimal/cmp.html.md)
* [otp.Operation.decimal.str](https://docs.pip.distribution.sol.onetick.com/api/operation/decimal/str.html.md)
