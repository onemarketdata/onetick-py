# onetick.py.Operation._\_rtruediv_\_

#### Operation.\_\_rtruediv_\_(other)

### Examples

```pycon
>>> t = otp.Tick(A=1, B=2.3)
>>> t['A'] /= t['B']
>>> t['B'] /= 2
>>> otp.run(t)[['A', 'B']]
          A     B
0  0.434783  1.15
```

#### SEE ALSO
[`__truediv__`](https://docs.pip.distribution.sol.onetick.com/api/operation/math/truediv.html.md#onetick.py.Operation.__truediv__)
