# otp.Operation.expr

#### *property* Operation.expr

Get expression to use in EP parameters.

#### SEE ALSO
[`Expr`](https://docs.pip.distribution.sol.onetick.com/api/misc/expr.html.md#onetick.py.core.column_operations.base.Expr)
