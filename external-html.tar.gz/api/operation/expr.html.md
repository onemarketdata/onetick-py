# otp.Operation.expr

#### *property* Operation.expr

Get expression to use in EP parameters.

#### SEE ALSO
[`Expr`](../misc/expr.md#onetick.py.core.column_operations.base.Expr)
