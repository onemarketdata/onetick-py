# State Variables

## Table Of Contents

* [otp.state.dynamic_tick](https://docs.pip.distribution.sol.onetick.com/api/state/dynamic_tick.html.md)
* [otp.state.tick_deque](https://docs.pip.distribution.sol.onetick.com/api/state/tick_deque.html.md)
* [otp.state.tick_deque_tick](https://docs.pip.distribution.sol.onetick.com/api/state/tick_deque_tick.html.md)
* [otp.state.tick_list](https://docs.pip.distribution.sol.onetick.com/api/state/tick_list.html.md)
* [otp.state.tick_list_tick](https://docs.pip.distribution.sol.onetick.com/api/state/tick_list_tick.html.md)
* [otp.state.tick_sequence_tick](https://docs.pip.distribution.sol.onetick.com/api/state/tick_sequence_tick.html.md)
* [otp.state.tick_set](https://docs.pip.distribution.sol.onetick.com/api/state/tick_set.html.md)
* [otp.state.tick_set_tick](https://docs.pip.distribution.sol.onetick.com/api/state/tick_set_tick.html.md)
* [otp.state.tick_set_unordered](https://docs.pip.distribution.sol.onetick.com/api/state/tick_set_unordered.html.md)
* [otp.state.var](https://docs.pip.distribution.sol.onetick.com/api/state/var.html.md)
