Cache related functions
=======================
